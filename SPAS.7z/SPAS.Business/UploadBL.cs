﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using SPAS.Data;
using SPAS.Business;
using SPAS.Business.Entity;

namespace SPAS.Business
{
     public class UploadBL
    {
         UploadDL oUploadDL = new UploadDL();
         public DataSet ValidateProcessProdHirUploadedData()
         {
             return oUploadDL.ValidateProcessProdHirUploadedData();
         }

         public DataSet ValidateProcessAGUpload(int userid)
         {

             SqlParameter[] param = new SqlParameter[1];
             param[0] = new SqlParameter("@UserID", userid);            
             return oUploadDL.ValidateProcessAGUploadData(param);
         }

         public DataSet ValidateProcessMaterialDtlsUploadedData()
         {
            
             return oUploadDL.ValidateProcessMaterialDtlsUploadedData();
         }
        public void cleartblMaterialDetailsTemptable()
        {

            oUploadDL.cleartblMaterialDetailsTemptable();
        }

        public DataSet ValidateProcessCustomerUploadedData()
         {
            
             return oUploadDL.ValidateProcessCustomerUploadedData();
         }

         public DataSet ValidateProcessShipToSoldToUploadedData()
         {
            
             return oUploadDL.ValidateProcessShipToSoldToUploadedData();
         }
         public DataSet Get_AllAg()
         {
             return oUploadDL.Get_Ag();
         }

         public DataSet Get_CustomerDetail(string strSearchText)
         {
             SqlParameter[] param = new SqlParameter[1];
             param[0] = new SqlParameter("@CustomerSearch", strSearchText);
             return oUploadDL.Get_CustomerDetail(param);
         }

         public DataSet Get_MaterialDetail(string strSearchText)
         {
             SqlParameter[] param = new SqlParameter[1];
             param[0] = new SqlParameter("@Search", strSearchText);
             return oUploadDL.Get_MaterialDetail(param);
         }

         public DataSet Get_ProductHiearchyDetail(string strSearchText)
         {
             SqlParameter[] param = new SqlParameter[1];
             param[0] = new SqlParameter("@Search", strSearchText);
             return oUploadDL.Get_ProductHiearchyDetail(param);
         }
         public DataSet Get_SearchAG(string strSearchText)
         {
             SqlParameter[] param = new SqlParameter[1];
             param[0] = new SqlParameter("@SearchText", strSearchText);
             return oUploadDL.GetsearchAG(param);
         }
         public bool Insert_NewAG(ref ArticleGroupEntity objag)

         {
             SqlParameter[] objsqlparameter = new SqlParameter[7];
             objsqlparameter[0] = new SqlParameter("@ReturnCode", objag.ReturnCode);
             objsqlparameter[0].Direction = ParameterDirection.Output;
             objsqlparameter[1] = new SqlParameter("@ReturnMessage", SqlDbType.VarChar, 500);
             objsqlparameter[1].Direction = ParameterDirection.Output;
             objsqlparameter[2] = new SqlParameter("@AGCode", objag.AgCode);
             objsqlparameter[3] = new SqlParameter("@AGDesc", objag.AgDescription);
             objsqlparameter[4] = new SqlParameter("@IsEditMode", objag.IsEditMode);
             objsqlparameter[5] = new SqlParameter("@createdby", objag.CreatedBy);
             objsqlparameter[6] = new SqlParameter("@AgID", objag.AgID);

             int i= oUploadDL.Insert_AG(objsqlparameter);
             objag.ReturnCode = Convert.ToInt16(objsqlparameter[0].Value);
             objag.ReturnMesage = objsqlparameter[1].Value.ToString();
             if (Convert.ToInt16(objsqlparameter[0].Value) == 0)
                 return true;
             else return false;
         }

         public DataSet Get_ShipToSoldToDetail(string strSearchText)
         {
             SqlParameter[] param = new SqlParameter[1];
             param[0] = new SqlParameter("@Search", strSearchText);
             return oUploadDL.Get_ShipToSoldToDetail(param);
         }

         public DataSet Get_AGforEdit(ref ArticleGroupEntity objentity)
         {
             SqlParameter[] param = new SqlParameter[1];
             param[0] = new SqlParameter("@AgID", objentity.AgID);
             return oUploadDL.GetAGforEdit(param);
 
         }
         public DataSet Get_ProductHierarchydata()
         {
             return oUploadDL.Get_ProductHierarchydata();
         }

         public DataSet Get_CustomeSoldToShipToData()
         {
             return oUploadDL.Get_CustomeSoldToShipToData();
         }
         public DataSet Get_GetCustomerDatas()
         {
             return oUploadDL.Get_GetCustomerData();
         }

         public DataSet Get_productpriceDta()
         {
             return oUploadDL.Get_productpriceDta();
         }
        public string update_Material_HSN(Int64 HSNCode, Int64 MaterialID, int userid)

        {
            SqlParameter[] param;
            param = new SqlParameter[4];
            param[0] = new SqlParameter("@MaterialID", SqlDbType.Decimal);
            param[0].Value = MaterialID;
            param[1] = new SqlParameter("@HSNCode", SqlDbType.Decimal);
            param[1].Value = HSNCode;
            param[2] = new SqlParameter("@UserID", SqlDbType.Decimal);
            param[2].Value = userid;
            param[3] = new SqlParameter("@ReturnMessage", SqlDbType.VarChar, 500);
            param[3].Direction = ParameterDirection.Output;
            oUploadDL.update_Material_HSN(param);

            return param[3].Value.ToString();
        }
    }
}
