﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SPAS.Data;
using System.Data;
using System.Data.SqlClient;
using SPAS.Business.Entity;
namespace SPAS.Business
{
  public  class BLRM
    {
      DLRM objdlrm = new DLRM();


      public DataSet GetChannellist()
      {
          return objdlrm.Get_Channel();
      }

      public DataSet GetRegions()
      {

          return objdlrm.Get_Region();
      }

      public DataSet Get_SearchRMmap(int stregion,int strchannel)
      {
          SqlParameter[] objSqlParameter = new SqlParameter[2];
          objSqlParameter[0] = new SqlParameter("@SearchRegion", stregion);
          objSqlParameter[1] = new SqlParameter("@SearchChannel", strchannel);
          return objdlrm.Get_RMmapSearch(objSqlParameter);

      }
      public DataSet GetRMmap()
      {
          return objdlrm.Get_RMmap();
      }

      public DataSet Get_users()
      {

          return objdlrm.Getusers();
      }
     
      public DataSet Get_RMforEdit(ref RMRegionChannelMap Objbgentity)
      {
          SqlParameter[] objSqlParameter = new SqlParameter[1];
          objSqlParameter[0] = new SqlParameter("@ID", Objbgentity.ID);
          return objdlrm.Get_RMmapEDIT(objSqlParameter);

      }

      public bool Insert_NewRmMap(ref RMRegionChannelMap objrmmap)
      {
          SqlParameter[] objSqlParameter = new SqlParameter[8];
          objSqlParameter[0] = new SqlParameter("@ReturnCode", objrmmap.ReturnCode);
          objSqlParameter[0].Direction = ParameterDirection.Output;
          objSqlParameter[1] = new SqlParameter("@ReturnMessage", SqlDbType.VarChar, 500);
          objSqlParameter[1].Direction = ParameterDirection.Output;
          objSqlParameter[2] = new SqlParameter("@IsEditMode", objrmmap.IsEditMode);
          objSqlParameter[3] = new SqlParameter("@RegionID", objrmmap.RegionID);
          objSqlParameter[4] = new SqlParameter("@channelID", objrmmap.channelID);
          objSqlParameter[5] = new SqlParameter("@createdby", objrmmap.CreatedBy);
          objSqlParameter[6] = new SqlParameter("@RMID", objrmmap.RMId);
          objSqlParameter[7] = new SqlParameter("@ID", objrmmap.ID);

          int i = objdlrm.Insert_RMMapping(objSqlParameter);
          objrmmap.ReturnCode = Convert.ToInt16(objSqlParameter[0].Value);
          objrmmap.ReturnMesage = objSqlParameter[1].Value.ToString();
          if (Convert.ToInt16(objSqlParameter[0].Value) == 0)
              return true;
          else return false;

      }


      

    }
}
