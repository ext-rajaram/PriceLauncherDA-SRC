﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SPAS.Data;
using System.Data.SqlClient;
using System.Data;


namespace SPAS.Business
{
    public class SOBL
    {
        SODL ObjSO = new SODL();
        public DataSet get_Order_Confirmation_Details(Int64 RequestID)
        {
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@RequestID", RequestID);
            return ObjSO.get_Order_Confirmation_Details(param);
        }

        public DataSet get_Order_Confirmation_Details_for_SO(Int64 RequestID)
        {
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@RequestID", RequestID);
            return ObjSO.get_Order_Confirmation_Details_for_SO(param);
        }

        public DataSet get_SO_Details_For_Order_Desk(Int64 RequestID)
        {
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@RequestID", RequestID);
            return ObjSO.get_SO_Details_For_Order_Desk(param);
        }

        public bool Save_RequestSOGenerationlDetails(ref RequestEntity objReqEntity)
        {

            SqlParameter[] objSqlParameter = new SqlParameter[12];

            objSqlParameter[0] = new SqlParameter("@RequestId", objReqEntity.RequestID);
            objSqlParameter[1] = new SqlParameter("@PONumber", objReqEntity.PONumber);
            objSqlParameter[2] = new SqlParameter("@PODate", objReqEntity.PODate);
            objSqlParameter[3] = new SqlParameter("@DeliveryInstruction", objReqEntity.DeliveryInstruction);
            objSqlParameter[4] = new SqlParameter("@CreatedBy", objReqEntity.CreatedBy);
            objSqlParameter[5] = new SqlParameter("@xmldetails", objReqEntity.xmldetails);
            objSqlParameter[6] = new SqlParameter("@ReturnCode", objReqEntity.ReturnCode);
            objSqlParameter[6].Direction = ParameterDirection.Output;
            objSqlParameter[7] = new SqlParameter("@ReturnMessage", SqlDbType.VarChar, 500);
            objSqlParameter[7].Direction = ParameterDirection.Output;
            objSqlParameter[8] = new SqlParameter("@CurrentRequestHeaderStatus", objReqEntity.RequestHeaderStatusid);
            if (objReqEntity.UploadName!= null)
                objSqlParameter[9] = new SqlParameter("@UploadName", objReqEntity.UploadName);
            if (objReqEntity.UploadFile != null)
                objSqlParameter[10] = new SqlParameter("@UploadFile", objReqEntity.UploadFile);
            if (objReqEntity.UploadFileType != null)
                objSqlParameter[11] = new SqlParameter("@UploadFileType", objReqEntity.UploadFileType);
            

            int i = ObjSO.Save_RequestSOGenerationlDetails(objSqlParameter);
            objReqEntity.ReturnCode = Convert.ToInt16(objSqlParameter[6].Value);
            objReqEntity.ReturnMesage = objSqlParameter[7].Value.ToString();
            if (Convert.ToInt16(objSqlParameter[6].Value) == 0)
                return true;
            else return false;

        }

        public DataSet get_SO_Header_View(Int64 RequestID)
        {
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@RequestID", RequestID);
            return ObjSO.get_SO_Header_View(param);
        }

        public DataSet get_SO_Details_View(Int64 SOId)
        {
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@SOId", SOId);
            return ObjSO.get_SO_Details_View(param);
        }

        public DataSet get_SO_UploadedFiles(Int64 SOId)
        {
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@SOId", SOId);
            return ObjSO.get_SO_UploadedFiles(param);
        }
    }
}
