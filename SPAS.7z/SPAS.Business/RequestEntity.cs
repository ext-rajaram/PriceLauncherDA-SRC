﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
namespace SPAS.Business
{
    public class RequestEntity
    {
        public static DataTable CreateRequest
        {
            get { return (DataTable)HttpContext.Current.Session["@CreateRequest"]; }
            set { HttpContext.Current.Session["@CreateRequest"] = value; }
        }
            public Int64 RequestID { get; set; }
            public Int64 SoldTo { get; set; }
            public Int64 ShipTo { get; set; }
            public long CreatedBy { get; set; }
            public int ReturnCode { get; set; }
            public string RegionCode { get; set; }
            public string SECode { get; set; }
            public Int64 RegionID { get; set; }
            public string Plant { get; set; }
            public string Channel { get; set; }
            public string Material { get; set; }
            public string MaterialDescription { get; set; }
            public string BGCode { get; set; }
            public string BUCode { get; set; }
            public string MAGCode { get; set; }
            public string SAGCode { get; set; }
            public string ValidityDate { get; set; }
            public string PurchaseOrderDate { get; set; }
            public string RequestedDeliveryDate { get; set; }
            public string ReasonforRequest { get; set; }
            public string PurchaseOrder { get; set; }
            public string xmldetails { get; set; }
            public string ReturnMesage { get; set; }
            public string GROUP2 { get; set; }
            public int IsCST { get; set; }
            public string Rolename { get; set; }
            public string PONumber { get; set; }
            public string PODate { get; set; }
            public string DeliveryInstruction { get; set; }
            public Int64 SAPSalesOrderNumber { get; set; }
            public int IsExistingCustome { get; set; }
            public string NewCustomeName { get; set; }
            public int RequestHeaderStatusid { get; set; }
            public Int64 SOId { get; set; }
            public string UploadName { get; set; }
            public byte[] UploadFile { get; set; }
            public string UploadFileType { get; set; }
            public static DataTable CreateRequestSOGenerate
            {
                get { return (DataTable)HttpContext.Current.Session["@CreateRequestSOGenerate"]; }
                set { HttpContext.Current.Session["@CreateRequestSOGenerate"] = value; }
            }

            public static string AttachFileNamePO
            {
                get { return (string)HttpContext.Current.Session["@AttachFileNamePO"]; }
                set { HttpContext.Current.Session["@AttachFileNamePO"] = value; }
            }
            public static string AttachFileTypePO
            {
                get { return (string)HttpContext.Current.Session["@AttachFileTypePO"]; }
                set { HttpContext.Current.Session["@AttachFileTypePO"] = value; }
            }

            public static byte[] AttachFilePO
            {
                get { return (byte[])HttpContext.Current.Session["@AttachFilePO"]; }
                set { HttpContext.Current.Session["@AttachFilePO"] = value; }
            }
    }
}
