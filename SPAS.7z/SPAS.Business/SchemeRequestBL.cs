﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SPAS.Data;
using System.Data.SqlClient;
using System.Data;
using SPAS.Business.Entity;


namespace SPAS.Business
{
    public class SchemeRequestBL
    {
        SchemeRequestDL ObjScheme = new SchemeRequestDL();
        public DataSet getAllGroup2()
        {
            return ObjScheme.getAllGroup2();
        }

        public DataSet getAllChannels()
        {
            return ObjScheme.getAllChannels();
        }

        public DataSet getBranchOnRegion(ref SchemeRequestEntity objReqEntity)
        {
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@Regions", objReqEntity.Regions);
            return ObjScheme.getBranchOnRegion(param);
        }

        public DataSet getCustomerOnRegion(ref SchemeRequestEntity objReqEntity)
        {
            SqlParameter[] param = new SqlParameter[3];
            param[0] = new SqlParameter("@Regions", objReqEntity.Regions);
            param[1] = new SqlParameter("@UserId", objReqEntity.UserID);
            param[2] = new SqlParameter("@ChannelId", objReqEntity.ChannelId);
            return ObjScheme.getCustomerOnRegion(param);
        }

        public DataSet getAllBG()
        {
            return ObjScheme.getAllBG();
        }

        public DataSet getBUOnBG(ref SchemeRequestEntity objReqEntity)
        {
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@BG", objReqEntity.BG);
            return ObjScheme.getBUOnBG(param);
        }

        public DataSet getSAGOnBU(ref SchemeRequestEntity objReqEntity)
        {
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@BU", objReqEntity.BU);
            return ObjScheme.getSAGOnBU(param);
        }

        public DataSet getProductOnSAG(ref SchemeRequestEntity objReqEntity)
        {
            SqlParameter[] param = new SqlParameter[2];
            param[0] = new SqlParameter("@SAG", objReqEntity.SAG);
            param[1] = new SqlParameter("@SearchText", objReqEntity.Product);

            return ObjScheme.getProductOnSAG(param);
        }

        public DataSet getApprovedRequests()
        {
            return ObjScheme.getApprovedRequests();
        }

        public DataSet getSchemeCustomersOnRequest(long RequestID, string strSearchText="")
        {
            SqlParameter[] param = new SqlParameter[2];
            param[0] = new SqlParameter("@RequestId", RequestID);
            param[1] = new SqlParameter("@CustomerSearch", strSearchText);

            return ObjScheme.getSchemeCustomersOnRequest(param);
        }

        public DataSet getSchemeBGOnRequest(long RequestID)
        {
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@RequestId", RequestID);

            return ObjScheme.getSchemeBGOnRequest(param);
        }

        public bool Save_SchemeRequestDetails(ref SchemeRequestEntity objReqEntity,ref System.Data.SqlClient.SqlConnection cn,ref System.Data.SqlClient.SqlTransaction sqltrn)
        {
            
            SqlParameter[] objSqlParameter = new SqlParameter[19];
            objSqlParameter[0] = new SqlParameter("@IsPrimary", objReqEntity.IsPrimary);
            objSqlParameter[1] = new SqlParameter("@AdhocType", objReqEntity.AdhocType);
            objSqlParameter[2] = new SqlParameter("@Regions", objReqEntity.Regions);
            objSqlParameter[3] = new SqlParameter("@FromDate", objReqEntity.FromDate);
            objSqlParameter[4] = new SqlParameter("@ToDate", objReqEntity.ToDate);
            objSqlParameter[5] = new SqlParameter("@BG", objReqEntity.BG);
            objSqlParameter[6] = new SqlParameter("@BU", objReqEntity.BU);
            objSqlParameter[7] = new SqlParameter("@SAG", objReqEntity.SAG);
            objSqlParameter[8] = new SqlParameter("@Product", objReqEntity.Product);
            objSqlParameter[9] = new SqlParameter("@ChannelId", objReqEntity.ChannelId);
            objSqlParameter[10] = new SqlParameter("@Branch", objReqEntity.Branch);
            objSqlParameter[11] = new SqlParameter("@Customer", objReqEntity.Customer);
            objSqlParameter[12] = new SqlParameter("@CreatedBy", objReqEntity.CreatedBy);
            objSqlParameter[13] = new SqlParameter("@StandardScheme", objReqEntity.StandardSchemes);
            objSqlParameter[14] = new SqlParameter("@ReturnCode", objReqEntity.ReturnCode);
            objSqlParameter[14].Direction = ParameterDirection.Output;
            objSqlParameter[15] = new SqlParameter("@ReturnMessage", SqlDbType.VarChar, 500);
            objSqlParameter[15].Direction = ParameterDirection.Output;
            objSqlParameter[16] = new SqlParameter("@RequesterComments", objReqEntity.RequesterComments);
            objSqlParameter[17] = new SqlParameter("@ReqId", objReqEntity.RequestID);
            objSqlParameter[18] = new SqlParameter("@IsPriorPeriod", objReqEntity.IsPriorPeriod);
            
            objSqlParameter[17].Direction = ParameterDirection.Output;
            int i = ObjScheme.Save_SchemeRequestDetails(objSqlParameter, ref cn,ref sqltrn);
            objReqEntity.ReturnCode = Convert.ToInt16(objSqlParameter[14].Value);
            objReqEntity.ReturnMesage = objSqlParameter[15].Value.ToString();
            objReqEntity.RequestID = Convert.ToInt64(objSqlParameter[17].Value);
            if (Convert.ToInt16(objSqlParameter[14].Value) == 0)
                return true;
            else return false;

        }


        public bool Save_SchemeAttachement(SchemeAttachmentEntity obAttachEntity, ref System.Data.SqlClient.SqlConnection cn, ref System.Data.SqlClient.SqlTransaction sqltrn)
        {

            SqlParameter[] objSqlParameter = new SqlParameter[11];
            objSqlParameter[0] = new SqlParameter("@RequestId", obAttachEntity.RequestID);
            objSqlParameter[1] = new SqlParameter("@SchemeDesc", obAttachEntity.SchemeDescription);
            objSqlParameter[2] = new SqlParameter("@AttachmentCalculation", obAttachEntity.AttachmentCalculation);
            objSqlParameter[3] = new SqlParameter("@AttachFileName", obAttachEntity.AttachFileName);
            //objSqlParameter[4] = new SqlParameter("@AttachFile", obAttachEntity.AttachFile);
            if (obAttachEntity.AttachFile != null && obAttachEntity.AttachFile.Length > 0)
            objSqlParameter[4] = new SqlParameter("@AttachFile", SqlDbType.VarBinary, obAttachEntity.AttachFile.Length, ParameterDirection.Input, true, 0, 0, "AttachFile", DataRowVersion.Current,(System.Data.SqlTypes.SqlBinary)obAttachEntity.AttachFile);
            else
                objSqlParameter[4] = new SqlParameter("@AttachFile", SqlDbType.VarBinary, 8000, ParameterDirection.Input, true, 0, 0, "AttachFile", DataRowVersion.Current, DBNull.Value);
           
            objSqlParameter[5] = new SqlParameter("@AttachFileType", obAttachEntity.AttachFileType);
            objSqlParameter[6] = new SqlParameter("@ExpectedSales", obAttachEntity.ExpectedSales);
            objSqlParameter[7] = new SqlParameter("@ExpectedPayout", obAttachEntity.ExpectedPayout);
            objSqlParameter[8] = new SqlParameter("@PercentagePayout", obAttachEntity.PercentagePayout);
            objSqlParameter[9] = new SqlParameter("@ReturnCode", obAttachEntity.ReturnCode);
            objSqlParameter[9].Direction = ParameterDirection.Output;
            objSqlParameter[10] = new SqlParameter("@ReturnMessage", SqlDbType.VarChar, 500);
            objSqlParameter[10].Direction = ParameterDirection.Output;


            int i = ObjScheme.Save_SchemeAttachement(objSqlParameter, ref cn,ref sqltrn);
            obAttachEntity.ReturnCode = Convert.ToInt16(objSqlParameter[9].Value);
            obAttachEntity.ReturnMesage = objSqlParameter[10].Value.ToString();
            if (Convert.ToInt16(objSqlParameter[9].Value) == 0)
                return true;
            else return false;

        }

        public bool Save_SchemeRollOut(ref SchemeRequestEntity objReqEntity)
        {

            SqlParameter[] objSqlParameter = new SqlParameter[4];
            objSqlParameter[0] = new SqlParameter("@RequestIdList", objReqEntity.RequestList);
            objSqlParameter[1] = new SqlParameter("@CreatedBy", objReqEntity.CreatedBy);
            objSqlParameter[2] = new SqlParameter("@ReturnCode", objReqEntity.ReturnCode);
            objSqlParameter[2].Direction = ParameterDirection.Output;
            objSqlParameter[3] = new SqlParameter("@ReturnMessage", SqlDbType.VarChar, 500);
            objSqlParameter[3].Direction = ParameterDirection.Output;

            int i = ObjScheme.Save_SchemeRollOut(objSqlParameter);
            objReqEntity.ReturnCode = Convert.ToInt16(objSqlParameter[2].Value);
            objReqEntity.ReturnMessage = objSqlParameter[3].Value.ToString();

            if (Convert.ToInt16(objSqlParameter[2].Value) == 0)
                return true;
            else return false;

        }

               

        public DataSet getSchemerequestdetails(long CreatedBy, string RequestNumber)
        {
            SqlParameter[] param = new SqlParameter[2];
            param[0] = new SqlParameter("@CreatedBy", CreatedBy);
            param[1] = new SqlParameter("@RequestNumber", RequestNumber);
            return ObjScheme.getSchemerequestdetails(param);
        }

        public DataSet getSchemerequestdetailsforApprover(long UserID, string RequestNumber)
        {
            SqlParameter[] param = new SqlParameter[2];
            param[0] = new SqlParameter("@UserID", UserID);
            param[1] = new SqlParameter("@RequestNumber", RequestNumber);
            return ObjScheme.getSchemerequestdetailsforApprover(param);
        }

        

        public int IsReqPendingwithsameCMM(Int64 RequestId, int CMMId)
        {

            return ObjScheme.IsReqPendingwithsameCMM(RequestId, CMMId);
        }

        public DataSet getRegionOnUser(SchemeRequestEntity objReqEntity)
        {
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@UserId", objReqEntity.UserID);
            return ObjScheme.getRegionOnUser(param);
        }

        public DataSet getAttachmentOnId(SchemeAttachmentEntity objAttachmentEntity,string strAttachType="")
        {
            SqlParameter[] param;
            if (strAttachType != "")
            {
                param = new SqlParameter[2];
                param[0] = new SqlParameter("@id", objAttachmentEntity.ID);
                param[1] = new SqlParameter("@AttachmentType", strAttachType);

            }
            else
            {
                param = new SqlParameter[1];
                param[0] = new SqlParameter("@id", objAttachmentEntity.ID);
            }
            return ObjScheme.getAttachmentOnId(param);
        }

        public bool CloseScheme(ref Entity.SchemeRequestEntity objReqEntity)
        {

            SqlParameter[] objSqlParameter = new SqlParameter[4];

            objSqlParameter[0] = new SqlParameter("@RequestId", objReqEntity.RequestID);
            objSqlParameter[1] = new SqlParameter("@UpdatedBy", objReqEntity.CreatedBy);
            objSqlParameter[2] = new SqlParameter("@ReturnCode", objReqEntity.ReturnCode);
            objSqlParameter[2].Direction = ParameterDirection.Output;
            objSqlParameter[3] = new SqlParameter("@ReturnMessage", SqlDbType.VarChar, 500);
            objSqlParameter[3].Direction = ParameterDirection.Output;


            int i = ObjScheme.CloseScheme(objSqlParameter);
            objReqEntity.ReturnCode = Convert.ToInt16(objSqlParameter[2].Value);
            objReqEntity.ReturnMesage = objSqlParameter[3].Value.ToString();
            if (Convert.ToInt16(objSqlParameter[2].Value) == 0)
                return true;
            else return false;

        }


        public int ReopenScheme(ref Entity.SchemeRequestEntity objReqEntity)
        {

            SqlParameter[] objSqlParameter = new SqlParameter[7];

            objSqlParameter[0] = new SqlParameter("@RequestId", objReqEntity.RequestID);
            objSqlParameter[1] = new SqlParameter("@CreatedBy", objReqEntity.CreatedBy);

            objSqlParameter[2] = new SqlParameter("@AttachFileName", objReqEntity.AttachFileNameReopenv);

            if (objReqEntity.AttachFileReopenv != null && objReqEntity.AttachFileReopenv.Length > 0)
                objSqlParameter[3] = new SqlParameter("@AttachFile", SqlDbType.VarBinary, objReqEntity.AttachFileReopenv.Length, ParameterDirection.Input, true, 0, 0, "AttachFile", DataRowVersion.Current, (System.Data.SqlTypes.SqlBinary)objReqEntity.AttachFileReopenv);
            else
                objSqlParameter[3] = new SqlParameter("@AttachFile", SqlDbType.VarBinary, 8000, ParameterDirection.Input, true, 0, 0, "AttachFile", DataRowVersion.Current, DBNull.Value);

            objSqlParameter[4] = new SqlParameter("@AttachFileType", objReqEntity.AttachFileTypeReopenv);
            objSqlParameter[5] = new SqlParameter("@ReturnCode", objReqEntity.ReturnCode);
            objSqlParameter[5].Direction = ParameterDirection.Output;
            objSqlParameter[6] = new SqlParameter("@ReturnMessage", SqlDbType.VarChar, 500);
            objSqlParameter[6].Direction = ParameterDirection.Output;

            int i = ObjScheme.ReopenScheme(objSqlParameter);
            objReqEntity.ReturnCode = Convert.ToInt16(objSqlParameter[5].Value);
            objReqEntity.ReturnMesage = objSqlParameter[6].Value.ToString();
           return i;

        }

        //public DataSet getSchemeSettlementdetails(string RequestNumber, string CNNo, string CustomerCode)
        //{
        //    SqlParameter[] param = new SqlParameter[3];          
        //    param[0] = new SqlParameter("@RequestNumber", RequestNumber);
        //    param[1] = new SqlParameter("@CNNo", CNNo);
        //    param[2] = new SqlParameter("@CustomerCode", CustomerCode);
            
        //    return ObjScheme.getSchemeSettlementdetails(param);
        //}


        public DataSet getAllChannelsForRM(int userid)
        {
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@UserId", userid);
            return ObjScheme.getAllChannelsForRM(param);
        }

        public bool Save_SchemeRollOutNew(ref SchemeRequestEntity objReqEntity)
        {

            SqlParameter[] objSqlParameter = new SqlParameter[3];
            objSqlParameter[0] = new SqlParameter("@RequestID", objReqEntity.RequestID);
            objSqlParameter[1] = new SqlParameter("@RollOutFileName", objReqEntity.RollOutFileName);
            objSqlParameter[2] = new SqlParameter("@CreatedBy", objReqEntity.CreatedBy);
           
            ObjScheme.Save_SchemeRollOutNew(objSqlParameter); 
            return true;
 
        }

    }
}
