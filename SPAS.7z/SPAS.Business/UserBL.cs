﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using SPAS.Data;
using System.Data.SqlClient;
using SPAS.Business.Entity;
namespace SPAS.Business
{
    public class UserBL
    {
        UserDL objDLUser = new UserDL();

        public DataSet ValidUser(string LoginID, string Password)
        {
              SqlParameter[] objSqlParameter = new SqlParameter[2];
            objSqlParameter[0] = new SqlParameter("@LoginID", LoginID);
            objSqlParameter[1] = new SqlParameter("@Password", Password);
            
            UserDL oUserDL = new UserDL();
            return oUserDL.ValidUser(objSqlParameter);
        }

        public DataSet ValidUserByUser(long UserID)
        {
            SqlParameter[] objSqlParameter = new SqlParameter[1];
            objSqlParameter[0] = new SqlParameter("@UserID", UserID);

            UserDL oUserDL = new UserDL();
            return oUserDL.ValidUserByUser(objSqlParameter);
        }
        public DataSet Getedituser(ref UserEntity objentity)
        {
            SqlParameter[] objSqlParameter = new SqlParameter[1];
            objSqlParameter[0] = new SqlParameter("@userID", objentity.UserId);
            return objDLUser.GetuserforEdit(objSqlParameter);
        }
        public DataSet Get_Searchusers(string strloginid, string strusername)
        {
            SqlParameter[] param = new SqlParameter[2];
            param[0] = new SqlParameter("@LoginID", strloginid);
            param[1] = new SqlParameter("@username", strusername);

            return objDLUser.Get_Searchuser(param);
        }
        public DataSet Get_Region()
        {
            return objDLUser.Get_AllRegions();
        }
        public DataSet Get_Roles()
        {
            return objDLUser.GetROles();
        }


        public bool Insertuser(ref UserEntity objuserentity)
        {
            SqlParameter[] objsqlparameter = new SqlParameter[12];
            objsqlparameter[0] = new SqlParameter("@ReturnCode", objuserentity.ReturnCode);
            objsqlparameter[0].Direction = ParameterDirection.Output;
            objsqlparameter[1] = new SqlParameter("@ReturnMessage", SqlDbType.VarChar, 500);
            objsqlparameter[1].Direction = ParameterDirection.Output;
            objsqlparameter[2] = new SqlParameter("@loginid", objuserentity.LoginID);
            objsqlparameter[3] = new SqlParameter("@username", objuserentity.Username);
            objsqlparameter[4] = new SqlParameter("@emailid", objuserentity.UserEmailID);
            objsqlparameter[5] = new SqlParameter("@roleid", objuserentity.RoleID);
            objsqlparameter[6] = new SqlParameter("@active", objuserentity.IsActive);
            objsqlparameter[7] = new SqlParameter("@createdby", objuserentity.CreatedBy);
            objsqlparameter[8] = new SqlParameter("@regionID", objuserentity.Region);
            objsqlparameter[9] = new SqlParameter("@IsEditMode", objuserentity.IsEditMode);
            objsqlparameter[10] = new SqlParameter("@userID", objuserentity.UserId);
            objsqlparameter[11] = new SqlParameter("@SEcode", objuserentity.SECode);//

            // throw new Exception("ENTER");
            int i = objDLUser.Insert_NewUsers(objsqlparameter);
           /// throw new Exception("ENTER" + i);

            objuserentity.ReturnCode = Convert.ToInt16(objsqlparameter[0].Value);
            objuserentity.ReturnMesage = objsqlparameter[1].Value.ToString();
            if (Convert.ToInt16(objsqlparameter[0].Value) == 0)
                return true;
            else return false;



        }

        public void UpdatePassword(string strOldPassword, string strNewPassword, long UserId, ref int ReturnCode, ref string ReturnMessage)
        {

            SqlParameter[] paramUpdateUserPassword;
            paramUpdateUserPassword = new SqlParameter[5];


            paramUpdateUserPassword[0] = new SqlParameter("@UserId", SqlDbType.BigInt);
            paramUpdateUserPassword[0].Value = UserId;
            paramUpdateUserPassword[1] = new SqlParameter("@OldPassword", SqlDbType.VarChar, 20);
            paramUpdateUserPassword[1].Value = strOldPassword;
            paramUpdateUserPassword[2] = new SqlParameter("@NewPassword", SqlDbType.VarChar, 20);
            paramUpdateUserPassword[2].Value = strNewPassword;
            paramUpdateUserPassword[3] = new SqlParameter("@ReturnCode", ReturnCode);
            paramUpdateUserPassword[3].Direction = ParameterDirection.Output;
            paramUpdateUserPassword[4] = new SqlParameter("@ReturnMessage", SqlDbType.VarChar, 500);
            paramUpdateUserPassword[4].Direction = ParameterDirection.Output;


            objDLUser.UpdatePassword(paramUpdateUserPassword);
            ReturnCode = Convert.ToInt16(paramUpdateUserPassword[3].Value);
            ReturnMessage = paramUpdateUserPassword[4].Value.ToString();
            
        }

        //public SqlDataReader ValidUser(string Password, long UserId)
        //{
        //    UserDL oUserDL = new UserDL();
        //    return oUserDL.ValidUser(Password, UserId);
        //}

        public DataSet Get_AllRegions_for_RM(int userid)
        {
            SqlParameter[] objsqlparameter = new SqlParameter[1];
            objsqlparameter[0] = new SqlParameter("@UserId", userid);
            return objDLUser.Get_AllRegions_for_RM(objsqlparameter);
        }

        public void UpdateLastLogin(long UserId)
        {
            UserDL oUserPasswordDL = new UserDL();
            SqlParameter[] paramUpdateLastLogin;
            paramUpdateLastLogin = new SqlParameter[1];
            paramUpdateLastLogin[0] = new SqlParameter("@UserId", SqlDbType.BigInt);
            paramUpdateLastLogin[0].Value = UserId;
            oUserPasswordDL.UpdateLastLogin(paramUpdateLastLogin);
        }
        public DataSet selectUserDetailsByUserName(string LoginID)
        {
            SqlParameter[] param;
            param = new SqlParameter[1];
            param[0] = new SqlParameter("@LoginID", SqlDbType.VarChar);
            param[0].Value = LoginID;
            UserDL oUserDL = new UserDL();
            return oUserDL.selectUserDetailsByUserName(param);
        }
    }
}
