﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SPAS.Data;
using System.Data;
using System.Data.SqlClient;
using SPAS.Business.Entity;

namespace SPAS.Business
{
    
    public class AdminBL
    {
        AdminDL ObjDLAdmin = new AdminDL();

        public DataSet Get_AllUsersOnRole(RoleEntity objRoleEntity)
        {
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@RoleId", objRoleEntity.RoleID);
            return ObjDLAdmin.Get_AllUsersOnRole(param);
        }

        public DataSet Get_AllSAG()
        {
            return ObjDLAdmin.Get_AllSAG();
        }

        public DataSet Get_AllBU()
        {
            return ObjDLAdmin.Get_AllBU();
        }

        public DataSet Get_AllPrdMgrSAGMapping()
        {
            return ObjDLAdmin.Get_AllPrdMgrSAGMapping();
        }

        public DataSet Get_AllCatgContrrBUMapping()
        {
            return ObjDLAdmin.Get_AllCatgContrrBUMapping();
        }
        public DataSet Get_plantstatemap()
        {
            return ObjDLAdmin.GetplantstateMap();
        }
       
           

        public DataSet Get_Allusers()
        {
            return ObjDLAdmin.Getallusers();
        }

        public DataSet Get_AllMktManagerMapping()
        {
            return ObjDLAdmin.Get_AllMktManagerMapping();
        }

        public bool Insert_PrdMgrSAGMapping(ref ProductManagerSAGMappingEntity objEntity)
        {
            SqlParameter[] objSqlParameter = new SqlParameter[6];
            objSqlParameter[0] = new SqlParameter("@ReturnCode", objEntity.ReturnCode);
            objSqlParameter[0].Direction = ParameterDirection.Output;
            objSqlParameter[1] = new SqlParameter("@ReturnMessage", SqlDbType.VarChar, 500);
            objSqlParameter[1].Direction = ParameterDirection.Output;
            objSqlParameter[2] = new SqlParameter("@IsEditMode", objEntity.IsEditMode);
            objSqlParameter[3] = new SqlParameter("@PrdMgrId", objEntity.ProdMgrId);
            objSqlParameter[4] = new SqlParameter("@SAGId", objEntity.SAGId);
            objSqlParameter[5] = new SqlParameter("@CreatedBy", objEntity.CreatedBy);

            int i = ObjDLAdmin.Insert_PrdMgrSAGMapping(objSqlParameter);
            objEntity.ReturnCode = Convert.ToInt16(objSqlParameter[0].Value);
            objEntity.ReturnMesage = objSqlParameter[1].Value.ToString();
            if (Convert.ToInt16(objSqlParameter[0].Value) == 0)
                return true;
            else return false;
        }

        public bool Insert_CatgContrBUMapping(ref CategControllerBUMappingEntity objEntity)
        {
            SqlParameter[] objSqlParameter = new SqlParameter[6];
            objSqlParameter[0] = new SqlParameter("@ReturnCode", objEntity.ReturnCode);
            objSqlParameter[0].Direction = ParameterDirection.Output;
            objSqlParameter[1] = new SqlParameter("@ReturnMessage", SqlDbType.VarChar, 500);
            objSqlParameter[1].Direction = ParameterDirection.Output;
            objSqlParameter[2] = new SqlParameter("@IsEditMode", objEntity.IsEditMode);
            objSqlParameter[3] = new SqlParameter("@MgrId", objEntity.CatgContrId);
            objSqlParameter[4] = new SqlParameter("@BUId", objEntity.BUId);
            objSqlParameter[5] = new SqlParameter("@CreatedBy", objEntity.CreatedBy);

            int i = ObjDLAdmin.Insert_CatgContrBUMapping(objSqlParameter);
            objEntity.ReturnCode = Convert.ToInt16(objSqlParameter[0].Value);
            objEntity.ReturnMesage = objSqlParameter[1].Value.ToString();
            if (Convert.ToInt16(objSqlParameter[0].Value) == 0)
                return true;
            else return false;
        }

        public bool Insert_MktManagerBUMapping(ref MarketingManagerBUMappingEntity objEntity)
        {
            SqlParameter[] objSqlParameter = new SqlParameter[6];
            objSqlParameter[0] = new SqlParameter("@ReturnCode", objEntity.ReturnCode);
            objSqlParameter[0].Direction = ParameterDirection.Output;
            objSqlParameter[1] = new SqlParameter("@ReturnMessage", SqlDbType.VarChar, 500);
            objSqlParameter[1].Direction = ParameterDirection.Output;
            objSqlParameter[2] = new SqlParameter("@IsEditMode", objEntity.IsEditMode);
            objSqlParameter[3] = new SqlParameter("@MgrId", objEntity.MktMgrId);
            objSqlParameter[4] = new SqlParameter("@BUId", objEntity.BUId);
            objSqlParameter[5] = new SqlParameter("@CreatedBy", objEntity.CreatedBy);

            int i = ObjDLAdmin.Insert_MktManagerBUMapping(objSqlParameter);
            objEntity.ReturnCode = Convert.ToInt16(objSqlParameter[0].Value);
            objEntity.ReturnMesage = objSqlParameter[1].Value.ToString();
            if (Convert.ToInt16(objSqlParameter[0].Value) == 0)
                return true;
            else return false;
        }
        public DataSet Getsearchplantmap(string searchtxt)
        {
            SqlParameter[] objSqlParameter = new SqlParameter[1];
            objSqlParameter[0] = new SqlParameter("@plantcode", searchtxt);

            return ObjDLAdmin.Getplantsearch(objSqlParameter);
        }

        public DataSet Getstate()
        {
            return ObjDLAdmin.GetStates();
        }

        public bool Insert_PlantStateMap(ref PlantStateMap objplant)
        {
            SqlParameter[] objSqlParameter = new SqlParameter[7];
            objSqlParameter[0] = new SqlParameter("@ReturnCode", objplant.ReturnCode);
            objSqlParameter[0].Direction = ParameterDirection.Output;
            objSqlParameter[1] = new SqlParameter("@ReturnMessage", SqlDbType.VarChar, 500);
            objSqlParameter[1].Direction = ParameterDirection.Output;
            objSqlParameter[2] = new SqlParameter("@IsEditMode", objplant.IsEditMode);
            objSqlParameter[3] = new SqlParameter("@Plant", objplant.Plant);
            objSqlParameter[4] = new SqlParameter("@state", objplant.Stateid);
            objSqlParameter[5] = new SqlParameter("@createdby", objplant.CreatedBy);
            objSqlParameter[6] = new SqlParameter("@PlantID", objplant.plantID);

            int i = ObjDLAdmin.InsertPlantstatemap(objSqlParameter);
            objplant.ReturnCode = Convert.ToInt16(objSqlParameter[0].Value);
            objplant.ReturnMesage = objSqlParameter[1].Value.ToString();
            if (Convert.ToInt16(objSqlParameter[0].Value) == 0)
                return true;
            else return false;
             
        }

        public DataSet GetPlantstateEdit(ref PlantStateMap objplant)
        {
            SqlParameter[] objSqlParameter = new SqlParameter[1];
            objSqlParameter[0] = new SqlParameter("@PlantID", objplant.plantID);
             return ObjDLAdmin.Getplantstate(objSqlParameter);
 
        }
        public DataSet Getmaterialcode(ref PlantStateMap objplant)
        {
            SqlParameter[] objSqlParameter = new SqlParameter[1];
            objSqlParameter[0] = new SqlParameter("@code", objplant.plantID);

            return ObjDLAdmin.Getmaterialcode(objSqlParameter);
 
        }

        public DataSet Get_SearchBG(string strsearch)
        {
            SqlParameter[] objSqlParameter = new SqlParameter[1];
            objSqlParameter[0] = new SqlParameter("@SearchText", strsearch);
            return ObjDLAdmin.Get_BgSearch(objSqlParameter);
 
        }
        public DataSet Get_BgforEdit(ref BusinessGroupEntity Objbgentity)
        {
            SqlParameter[] objSqlParameter = new SqlParameter[1];
            objSqlParameter[0] = new SqlParameter("@BgID", Objbgentity.BgID);
            return ObjDLAdmin.Get_BgEdit(objSqlParameter);
 
        }

     
       

        public bool Insert_NewBG(ref BusinessGroupEntity objbg)
        {
            SqlParameter[] objsqlparameter = new SqlParameter[7];
            objsqlparameter[0] = new SqlParameter("@ReturnCode", objbg.ReturnCode);
            objsqlparameter[0].Direction = ParameterDirection.Output;
            objsqlparameter[1] = new SqlParameter("@ReturnMessage", SqlDbType.VarChar, 500);
            objsqlparameter[1].Direction = ParameterDirection.Output;
            objsqlparameter[2] = new SqlParameter("@BGCode", objbg.BgCode);
            objsqlparameter[3] = new SqlParameter("@BGDesc", objbg.BgDescription);
            objsqlparameter[4] = new SqlParameter("@IsEditMode", objbg.IsEditMode);
            objsqlparameter[5] = new SqlParameter("@createdby", objbg.CreatedBy);
            objsqlparameter[6] = new SqlParameter("@BgID", objbg.BgID);

            int i = ObjDLAdmin.Insert_BG(objsqlparameter);
            objbg.ReturnCode = Convert.ToInt16(objsqlparameter[0].Value);
            objbg.ReturnMesage = objsqlparameter[1].Value.ToString();
            if (Convert.ToInt16(objsqlparameter[0].Value) == 0)
                return true;
            else return false;
        }


        public DataSet Get_BG()
        {
            return ObjDLAdmin.Get_Bg();
        }

        public DataSet Get_BU()
        {
            return ObjDLAdmin.Get_Bu();
        }
        public DataSet Get_SearchBU(string strsearch)
        {
            SqlParameter[] objSqlParameter = new SqlParameter[1];
            objSqlParameter[0] = new SqlParameter("@SearchText", strsearch);
            return ObjDLAdmin.Get_BuSearch(objSqlParameter);

        }

        public DataSet Get_BuforEdit(ref BusinessUnitEntity Objbgentity)
        {
            SqlParameter[] objSqlParameter = new SqlParameter[1];
            objSqlParameter[0] = new SqlParameter("@BuID", Objbgentity.BuID);
            return ObjDLAdmin.Get_BuEdit(objSqlParameter);

        }


        public bool Insert_NewBU(ref BusinessUnitEntity objbu)
        {
            SqlParameter[] objsqlparameter = new SqlParameter[8];
            objsqlparameter[0] = new SqlParameter("@ReturnCode", objbu.ReturnCode);
            objsqlparameter[0].Direction = ParameterDirection.Output;
            objsqlparameter[1] = new SqlParameter("@ReturnMessage", SqlDbType.VarChar, 500);
            objsqlparameter[1].Direction = ParameterDirection.Output;
            objsqlparameter[2] = new SqlParameter("@BUCode", objbu.BuCode);
            objsqlparameter[3] = new SqlParameter("@BUDesc", objbu.BuDescription);
            objsqlparameter[4] = new SqlParameter("@IsEditMode", objbu.IsEditMode);
            objsqlparameter[5] = new SqlParameter("@createdby", objbu.CreatedBy);
            objsqlparameter[6] = new SqlParameter("@BuID", objbu.BuID);
            objsqlparameter[7] = new SqlParameter("@BGID", objbu.BgID);

            int i = ObjDLAdmin.Insert_BU(objsqlparameter);
            objbu.ReturnCode = Convert.ToInt16(objsqlparameter[0].Value);
            objbu.ReturnMesage = objsqlparameter[1].Value.ToString();
            if (Convert.ToInt16(objsqlparameter[0].Value) == 0)
                return true;
            else return false;
        }

        public DataSet Get_Mag()
        {
            return ObjDLAdmin.Get_mag();
        }

        public DataSet Get_SearchMAG(string strsearch)
        {
            SqlParameter[] objSqlParameter = new SqlParameter[1];
            objSqlParameter[0] = new SqlParameter("@SearchText", strsearch);
            return ObjDLAdmin.Get_MagSearch(objSqlParameter);

        }



        public DataSet Get_MagforEdit(ref MagEntity Objmagentity)
        {
            SqlParameter[] objSqlParameter = new SqlParameter[1];
            objSqlParameter[0] = new SqlParameter("@MagID", Objmagentity.MagID);
            return ObjDLAdmin.Get_MagEdit(objSqlParameter);

        }


        public bool Insert_NewMAG(ref MagEntity objbu)
        {
            SqlParameter[] objsqlparameter = new SqlParameter[7];
            objsqlparameter[0] = new SqlParameter("@ReturnCode", objbu.ReturnCode);
            objsqlparameter[0].Direction = ParameterDirection.Output;
            objsqlparameter[1] = new SqlParameter("@ReturnMessage", SqlDbType.VarChar, 500);
            objsqlparameter[1].Direction = ParameterDirection.Output;
            objsqlparameter[2] = new SqlParameter("@MAGCode", objbu.MagCode);
            objsqlparameter[3] = new SqlParameter("@MAGDesc", objbu.MagDescription);
            objsqlparameter[4] = new SqlParameter("@IsEditMode", objbu.IsEditMode);
            objsqlparameter[5] = new SqlParameter("@createdby", objbu.CreatedBy);
            objsqlparameter[6] = new SqlParameter("@MagID", objbu.MagID);

            int i = ObjDLAdmin.Insert_MAG(objsqlparameter);
            objbu.ReturnCode = Convert.ToInt16(objsqlparameter[0].Value);
            objbu.ReturnMesage = objsqlparameter[1].Value.ToString();
            if (Convert.ToInt16(objsqlparameter[0].Value) == 0)
                return true;
            else return false;
        }



        public DataSet Get_Min3npsearch(string strsearch)
        {
            SqlParameter[] objSqlParameter = new SqlParameter[1];
            objSqlParameter[0] = new SqlParameter("@search", strsearch);
            return ObjDLAdmin.Get_Min3npSearch(objSqlParameter);

        }


        public DataSet ValidateProcessminenpData()
        {
            return ObjDLAdmin.ValidateProcessmin3npUploadedData();
        }

        public DataSet ValidateProcessCPPData()
        {
            return ObjDLAdmin.ValidateProcessCPPData();
        }

        

     

        public DataSet ValidateAndProcessmaterialstatetax()
        {

            return ObjDLAdmin.ValidateAndProcessmaterialstatetax();
        }

        

        public DataSet Get_searchMatrerilstatetax(string txtsearch)
        {
             SqlParameter[] objSqlParameter = new SqlParameter[1];
             objSqlParameter[0] = new SqlParameter("@searchtext", txtsearch);
             return ObjDLAdmin.Get_searchMatrerilstatetax(objSqlParameter);
        }

        public DataSet Get_SearchTaxBu(string txtsearch)
        {
            SqlParameter[] objSqlParameter = new SqlParameter[1];
            objSqlParameter[0] = new SqlParameter("@searchtxt", txtsearch);
            return ObjDLAdmin.Get_SearchTaxBu(objSqlParameter);
        }
        public DataSet ValidateAndProcessBUstateregiontax()
        {
            try
            {
                return ObjDLAdmin.ValidateAndProcessBUstateregiontax();
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public DataSet Get_Sag()
        {
            return ObjDLAdmin.Get_sag();
        }


        public DataSet Get_SagSearch(string strsearch)
        {
            SqlParameter[] objSqlParameter = new SqlParameter[1];
            objSqlParameter[0] = new SqlParameter("@SearchText", strsearch);
            return ObjDLAdmin.GetSagSearch(objSqlParameter);

        }


        public bool Insert_NewSag(ref MagEntity objbu)
        {
            SqlParameter[] objsqlparameter = new SqlParameter[7];
            objsqlparameter[0] = new SqlParameter("@ReturnCode", objbu.ReturnCode);
            objsqlparameter[0].Direction = ParameterDirection.Output;
            objsqlparameter[1] = new SqlParameter("@ReturnMessage", SqlDbType.VarChar, 500);
            objsqlparameter[1].Direction = ParameterDirection.Output;
            objsqlparameter[2] = new SqlParameter("@SAGDesc", objbu.SagDescription);
            objsqlparameter[3] = new SqlParameter("@IsEditMode", objbu.IsEditMode);
            objsqlparameter[4] = new SqlParameter("@createdby", objbu.CreatedBy);
            objsqlparameter[5] = new SqlParameter("@SagID", objbu.SagID);
            objsqlparameter[6] = new SqlParameter("@BUID", objbu.BUId);

            int i = ObjDLAdmin.Insert_SAG(objsqlparameter);
            objbu.ReturnCode = Convert.ToInt16(objsqlparameter[0].Value);
            objbu.ReturnMesage = objsqlparameter[1].Value.ToString();
            if (Convert.ToInt16(objsqlparameter[0].Value) == 0)
                return true;
            else return false;
        }


        public DataSet Get_SagforEdit(ref MagEntity Objmagentity)
        {
            SqlParameter[] objSqlParameter = new SqlParameter[1];
            objSqlParameter[0] = new SqlParameter("@SagID", Objmagentity.SagID);
            return ObjDLAdmin.Get_SagEdit(objSqlParameter);

        }

        public DataSet Get_Group2COD()
        {

            return ObjDLAdmin.Get_Group2cod();
        }

        public bool Insert_NewGroup2(ref MagEntity objbu)
        {
            SqlParameter[] objsqlparameter = new SqlParameter[6];
            objsqlparameter[0] = new SqlParameter("@ReturnCode", objbu.ReturnCode);
            objsqlparameter[0].Direction = ParameterDirection.Output;
            objsqlparameter[1] = new SqlParameter("@ReturnMessage", SqlDbType.VarChar, 500);
            objsqlparameter[1].Direction = ParameterDirection.Output;
            objsqlparameter[2] = new SqlParameter("@Group2COD", objbu.Goup2);

            int i = ObjDLAdmin.Insert_Group2(objsqlparameter);
            objbu.ReturnCode = Convert.ToInt16(objsqlparameter[0].Value);
            objbu.ReturnMesage = objsqlparameter[1].Value.ToString();
            if (Convert.ToInt16(objsqlparameter[0].Value) == 0)
                return true;
            else return false;
        }

        public DataSet Delete_Group2(ref MagEntity Objmagentity)
        {
            SqlParameter[] objSqlParameter = new SqlParameter[1];
            objSqlParameter[0] = new SqlParameter("@Group2", Objmagentity.Goup2);
            return ObjDLAdmin.Delete_Group2cod(objSqlParameter);
        }

        public DataSet Get_ExchangeRates()
        {
            return ObjDLAdmin.Get_ExchangeRates();
        }



        public bool Insert_Exchangerate(ref ExchangeRate objrate)
        {
            SqlParameter[] objsqlparameter = new SqlParameter[7];
            objsqlparameter[0] = new SqlParameter("@ReturnCode", objrate.ReturnCode);
            objsqlparameter[0].Direction = ParameterDirection.Output;
            objsqlparameter[1] = new SqlParameter("@ReturnMessage", SqlDbType.VarChar, 500);
            objsqlparameter[1].Direction = ParameterDirection.Output;
            objsqlparameter[2] = new SqlParameter("@Year", objrate.year);
            objsqlparameter[3] = new SqlParameter("@Month", objrate.month);
            objsqlparameter[4] = new SqlParameter("@rate", objrate.rate);
            objsqlparameter[5] = new SqlParameter("@IsEditMode", objrate.IsEditMode);
            objsqlparameter[6] = new SqlParameter("@ID", objrate.RateID);
            int i = ObjDLAdmin.Insert_Exchangerate(objsqlparameter);
            objrate.ReturnCode = Convert.ToInt16(objsqlparameter[0].Value);
            objrate.ReturnMesage = objsqlparameter[1].Value.ToString();
            if (Convert.ToInt16(objsqlparameter[0].Value) == 0)
                return true;
            else return false;
        }

        public DataSet Get_exchangerateEdit(ref ExchangeRate objrate)
        {
            SqlParameter[] objSqlParameter = new SqlParameter[1];
            objSqlParameter[0] = new SqlParameter("@ID", objrate.RateID);
            return ObjDLAdmin.Get_exchangerateEdit(objSqlParameter);
        }


        public DataSet Get_CppMasters(string strsearch)
        {
            SqlParameter[] objSqlParameter = new SqlParameter[1];
            objSqlParameter[0] = new SqlParameter("@SearchText", strsearch);
            return ObjDLAdmin.Get_CppMaster(objSqlParameter);
        }

        public DataSet Get_Min3npdata()

        {
            return ObjDLAdmin.Get_Min3npdata();
        }

        public DataSet Get_duplicateusers()
        {

            return ObjDLAdmin.Get_duplicateusers();
        }

        public DataSet Get_TaxBUdata()
        {

            return ObjDLAdmin.Get_TaxBUdata();
        }

        public DataSet Get_MaterialTaxData()
        {

            return ObjDLAdmin.Get_MaterialTaxData();
        }


        public DataSet Get_users()
        {

            return ObjDLAdmin.Get_uers();
        }
        public DataSet Get_regions()
        {

            return ObjDLAdmin.Get_Regions();
        }

        public DataSet Get_Searchregionorderdesk(string strsearch)
        {
            SqlParameter[] objSqlParameter = new SqlParameter[1];
            objSqlParameter[0] = new SqlParameter("@SearchText", strsearch);
            return ObjDLAdmin.Get_stateorderuser(objSqlParameter);

        }

        public bool Insert_Regionorderdesk(ref UserEntity userentity)
        {
            SqlParameter[] objsqlparameter = new SqlParameter[6];
            objsqlparameter[0] = new SqlParameter("@ReturnCode", userentity.ReturnCode);
            objsqlparameter[0].Direction = ParameterDirection.Output;
            objsqlparameter[1] = new SqlParameter("@ReturnMessage", SqlDbType.VarChar, 500);
            objsqlparameter[1].Direction = ParameterDirection.Output;
            objsqlparameter[2] = new SqlParameter("@userID", userentity.UserId);
            objsqlparameter[3] = new SqlParameter("@staetID", userentity.Region);             
            objsqlparameter[4] = new SqlParameter("@IsEditMode", userentity.IsEditMode);
            objsqlparameter[5] = new SqlParameter("@id", userentity.RoleID);
            int i = ObjDLAdmin.Insert_NewRegionorderdesk(objsqlparameter);
            userentity.ReturnCode = Convert.ToInt16(objsqlparameter[0].Value);
            userentity.ReturnMesage = objsqlparameter[1].Value.ToString();
            if (Convert.ToInt16(objsqlparameter[0].Value) == 0)
                return true;
            else return false;
        }


        public DataSet Get_regionorderforEdit(ref UserEntity userentity)
        {
            SqlParameter[] objSqlParameter = new SqlParameter[1];
            objSqlParameter[0] = new SqlParameter("@USerID", userentity.UserId);
            return ObjDLAdmin.Get_regionorderforEdit(objSqlParameter);
 
        }

        public DataSet Delete_Regionorder(ref UserEntity userentity)
        {
            SqlParameter[] objSqlParameter = new SqlParameter[1];
            objSqlParameter[0] = new SqlParameter("@ID", userentity.UserId);
            return ObjDLAdmin.Delete_orderdetails(objSqlParameter);
        }
        public DataSet Get_BgcodeDescription()
        {

            return ObjDLAdmin.Get_BGCodeDesc();
        }

        public DataSet Get_BucodeDescription()
        {

            return ObjDLAdmin.Get_BUCodeDesc();
        }
        public DataSet GetChannellist()
        {
            return ObjDLAdmin.Get_ChannelSearch();
        }

        public DataSet Get_ChannelforEdit(ref BusinessUnitEntity Objbgentity)
        {
            SqlParameter[] objSqlParameter = new SqlParameter[1];
            objSqlParameter[0] = new SqlParameter("@ChannelID", Objbgentity.ChannelID);
            return ObjDLAdmin.Get_ChannelEdit(objSqlParameter);

        }

        public bool Insert_NewChannel(ref BusinessUnitEntity objbg)
        {
            SqlParameter[] objsqlparameter = new SqlParameter[5];
            objsqlparameter[0] = new SqlParameter("@ReturnCode", objbg.ReturnCode);
            objsqlparameter[0].Direction = ParameterDirection.Output;
            objsqlparameter[1] = new SqlParameter("@ReturnMessage", SqlDbType.VarChar, 500);
            objsqlparameter[1].Direction = ParameterDirection.Output;
            objsqlparameter[2] = new SqlParameter("@channel", objbg.Channel);
            objsqlparameter[3] = new SqlParameter("@Id", objbg.ChannelID);
            objsqlparameter[4] = new SqlParameter("@IsEditMode", objbg.IsEditMode);
             
             

            int i = ObjDLAdmin.Insert_Channel(objsqlparameter);
            objbg.ReturnCode = Convert.ToInt16(objsqlparameter[0].Value);
            objbg.ReturnMesage = objsqlparameter[1].Value.ToString();
            if (Convert.ToInt16(objsqlparameter[0].Value) == 0)
                return true;
            else return false;
        }
        public DataSet Get_Channel()
        {

            return ObjDLAdmin.Get_Channel();
        }

        public DataSet Get_Searchgroupchannel(string strsearch)
        {
            SqlParameter[] objSqlParameter = new SqlParameter[1];
            objSqlParameter[0] = new SqlParameter("@SearchText", strsearch);
            return ObjDLAdmin.Get_groupSearch(objSqlParameter);

        }

        public DataSet Get_groupforEdit(ref BusinessUnitEntity Objbgentity)
        {
            SqlParameter[] objSqlParameter = new SqlParameter[1];
            objSqlParameter[0] = new SqlParameter("@SearchText", Objbgentity.Channel);
            return ObjDLAdmin.Get_GroupChannelEdit(objSqlParameter);

        }


        public bool Insert_NewGroup2Map(ref BusinessUnitEntity objbg)
        {
            SqlParameter[] objsqlparameter = new SqlParameter[6];
            objsqlparameter[0] = new SqlParameter("@ReturnCode", objbg.ReturnCode);
            objsqlparameter[0].Direction = ParameterDirection.Output;
            objsqlparameter[1] = new SqlParameter("@ReturnMessage", SqlDbType.VarChar, 500);
            objsqlparameter[1].Direction = ParameterDirection.Output;
            objsqlparameter[2] = new SqlParameter("@Group2", objbg.group);
            objsqlparameter[3] = new SqlParameter("@editgroup", objbg.EditGroup);
            objsqlparameter[4] = new SqlParameter("@channelID", objbg.ChannelID);
            objsqlparameter[5] = new SqlParameter("@IsEditMode", objbg.IsEditMode);



            int i = ObjDLAdmin.Insert_Group(objsqlparameter);
            objbg.ReturnCode = Convert.ToInt16(objsqlparameter[0].Value);
            objbg.ReturnMesage = objsqlparameter[1].Value.ToString();
            if (Convert.ToInt16(objsqlparameter[0].Value) == 0)
                return true;
            else return false;
        }

        public DataSet Get_HNSMaster()
        {
            return ObjDLAdmin.Get_HNSMaster();
        }

        public DataSet GetEditHNSMaster(ref HSNMaster objrate)
        {
            SqlParameter[] objSqlParameter = new SqlParameter[1];
            objSqlParameter[0] = new SqlParameter("@HSNID", objrate.HSNId);
            return ObjDLAdmin.GetEditHNSMaster(objSqlParameter);
        }

        public bool Insert_HSNMaster(ref HSNMaster objrate)
        {
            SqlParameter[] objsqlparameter = new SqlParameter[6];
            objsqlparameter[0] = new SqlParameter("@ReturnCode", objrate.ReturnCode);
            objsqlparameter[0].Direction = ParameterDirection.Output;
            objsqlparameter[1] = new SqlParameter("@ReturnMessage", SqlDbType.VarChar, 500);
            objsqlparameter[1].Direction = ParameterDirection.Output;
            objsqlparameter[2] = new SqlParameter("@HSNId", objrate.HSNId);
            objsqlparameter[3] = new SqlParameter("@HSN", objrate.HSN);
            objsqlparameter[4] = new SqlParameter("@TaxPercentage", objrate.TaxPercentage);
            objsqlparameter[5] = new SqlParameter("@IsEditMode", objrate.IsEditMode);
            int i = ObjDLAdmin.Insert_HSNMaster(objsqlparameter);
            objrate.ReturnCode = Convert.ToInt16(objsqlparameter[0].Value);
            objrate.ReturnMesage = objsqlparameter[1].Value.ToString();
            if (Convert.ToInt16(objsqlparameter[0].Value) == 0)
                return true;
            else return false;
        }

    }
}
