﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SPAS.Data;
using System.Data.SqlClient;
using System.Data;
using SPAS.Business.Entity;


namespace SPAS.Business
{
    public class SchemeSettlementRequestBL
    {
        SchemeSettlementRequestDL ObjSchemeSettle = new SchemeSettlementRequestDL();

        public DataSet getSchemeSettlementDetails(long UserID, string RequestNumber, string FromDate, string ToDate)
        {
            SqlParameter[] param = new SqlParameter[4];
            param[0] = new SqlParameter("@UserID", UserID);
            param[1] = new SqlParameter("@RequestNumber", RequestNumber);
            param[2] = new SqlParameter("@FromDate", FromDate);
            param[3] = new SqlParameter("@ToDate", ToDate);
            return ObjSchemeSettle.getSchemeSettlementDetails(param);
        }

        public bool Save_SchemeSettlementDetails(ref SchemeSettlementEntity objReqEntity)
        {

            SqlParameter[] objSqlParameter = new SqlParameter[11];
            objSqlParameter[0] = new SqlParameter("@RequestId", objReqEntity.RequestID);
            objSqlParameter[1] = new SqlParameter("@Customers", objReqEntity.Customer);
            objSqlParameter[2] = new SqlParameter("@BGId", objReqEntity.BGId);
            objSqlParameter[3] = new SqlParameter("@AmountSettled", objReqEntity.AmountSettled);
            objSqlParameter[4] = new SqlParameter("@Remarks", objReqEntity.Remarks);
            objSqlParameter[5] = new SqlParameter("@AttachFileName", objReqEntity.SettleAttachFileName);

            if (objReqEntity.SettleAttachFile != null && objReqEntity.SettleAttachFile.Length > 0)
                objSqlParameter[6] = new SqlParameter("@AttachFile", SqlDbType.VarBinary, objReqEntity.SettleAttachFile.Length, ParameterDirection.Input, true, 0, 0, "AttachFile", DataRowVersion.Current, (System.Data.SqlTypes.SqlBinary)objReqEntity.SettleAttachFile);
            else
                objSqlParameter[6] = new SqlParameter("@AttachFile", SqlDbType.VarBinary, 8000, ParameterDirection.Input, true, 0, 0, "AttachFile", DataRowVersion.Current, DBNull.Value);

            objSqlParameter[7] = new SqlParameter("@AttachFileType", objReqEntity.SettleAttachFileType);

            objSqlParameter[8] = new SqlParameter("@CreatedBy", objReqEntity.CreatedBy);
            objSqlParameter[9] = new SqlParameter("@ReturnCode", objReqEntity.ReturnCode);
            objSqlParameter[9].Direction = ParameterDirection.Output;
            objSqlParameter[10] = new SqlParameter("@ReturnMessage", SqlDbType.VarChar, 500);
            objSqlParameter[10].Direction = ParameterDirection.Output;

            int i = ObjSchemeSettle.Save_SchemeSettlementDetails(objSqlParameter);
            objReqEntity.ReturnCode = Convert.ToInt16(objSqlParameter[9].Value);
            objReqEntity.ReturnMessage = objSqlParameter[10].Value.ToString();

            if (Convert.ToInt16(objSqlParameter[9].Value) == 0)
                return true;
            else return false;

        }

        public DataSet getSchemeSettlementOnRequest(long RequestId)
        {
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@RequestId", RequestId);


            return ObjSchemeSettle.getSchemeSettlementOnRequest(param);
        }

        public DataSet getSchemeCustomersSettledAmt(long RequestID, long CustomerCode)
        {
            SqlParameter[] param = new SqlParameter[2];
            param[0] = new SqlParameter("@RequestId", RequestID);
            param[1] = new SqlParameter("@CustomerCode", CustomerCode);

            return ObjSchemeSettle.getSchemeCustomersSettledAmt(param);
        }

        public DataSet getSchemeSettledDetails(long UserID, string SettlementSerialNo, string FromDate, string ToDate)
        {
            SqlParameter[] param = new SqlParameter[4];
            param[0] = new SqlParameter("@CreatedBy", UserID);
            param[1] = new SqlParameter("@SettlementSerialNo", SettlementSerialNo);
            param[2] = new SqlParameter("@FromDate", FromDate);
            param[3] = new SqlParameter("@ToDate", ToDate);
            return ObjSchemeSettle.getSchemeSettledDetails(param);
        }

        public bool Submit_SchemeSettlementRequest(ref SchemeSettlementEntity objReqEntity)
        {

            SqlParameter[] objSqlParameter = new SqlParameter[4];
            objSqlParameter[0] = new SqlParameter("@RequestId", objReqEntity.RequestID);
            objSqlParameter[1] = new SqlParameter("@CreatedBy", objReqEntity.CreatedBy);
            objSqlParameter[2] = new SqlParameter("@ReturnCode", objReqEntity.ReturnCode);
            objSqlParameter[2].Direction = ParameterDirection.Output;
            objSqlParameter[3] = new SqlParameter("@ReturnMessage", SqlDbType.VarChar, 500);
            objSqlParameter[3].Direction = ParameterDirection.Output;

            int i = ObjSchemeSettle.Submit_SchemeSettlementRequest(objSqlParameter);
            objReqEntity.ReturnCode = Convert.ToInt16(objSqlParameter[2].Value);
            objReqEntity.ReturnMessage = objSqlParameter[3].Value.ToString();

            if (Convert.ToInt16(objSqlParameter[2].Value) == 0)
                return true;
            else return false;

        }

        public bool DeleteSettlement(ref Entity.SchemeSettlementEntity objSettleEntity)
        {

            SqlParameter[] objSqlParameter = new SqlParameter[3];

            objSqlParameter[0] = new SqlParameter("@SettlementId", objSettleEntity.SettlementID);
            objSqlParameter[1] = new SqlParameter("@ReturnCode", objSettleEntity.ReturnCode);
            objSqlParameter[1].Direction = ParameterDirection.Output;
            objSqlParameter[2] = new SqlParameter("@ReturnMessage", SqlDbType.VarChar, 500);
            objSqlParameter[2].Direction = ParameterDirection.Output;


            int i = ObjSchemeSettle.DeleteSettlement(objSqlParameter);
            objSettleEntity.ReturnCode = Convert.ToInt16(objSqlParameter[1].Value);
            objSettleEntity.ReturnMesage = objSqlParameter[2].Value.ToString();
            if (Convert.ToInt16(objSqlParameter[1].Value) == 0)
                return true;
            else return false;

        }


        public DataSet getSchemeSettledCNDetails(Int64 SettlementID)
        {
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@SettlementID", SettlementID);
            return ObjSchemeSettle.getSchemeSettledCNDetails(param);
        }

        public int save_Scheme_Settled_CN_deatils(ref Entity.SchemeSettledCNEntity objSettledCNEntity)
        {

            SqlParameter[] objSqlParameter = new SqlParameter[6];

            objSqlParameter[0] = new SqlParameter("@SettelmentId", objSettledCNEntity.SettlementID);
            objSqlParameter[1] = new SqlParameter("@CreditNoteNo", objSettledCNEntity.CreditNoteNo);
            objSqlParameter[2] = new SqlParameter("@CreditNoteDate", objSettledCNEntity.CreditNoteDate);
            objSqlParameter[3] = new SqlParameter("@UserID", objSettledCNEntity.CreatedBy);
            objSqlParameter[4] = new SqlParameter("@ReturnCode", objSettledCNEntity.ReturnCode);
            objSqlParameter[4].Direction = ParameterDirection.Output;
            objSqlParameter[5] = new SqlParameter("@ReturnMessage", SqlDbType.VarChar, 500);
            objSqlParameter[5].Direction = ParameterDirection.Output;

            int i = ObjSchemeSettle.save_Scheme_Settled_CN_deatils(objSqlParameter);
            objSettledCNEntity.ReturnCode = Convert.ToInt16(objSqlParameter[4].Value);
            objSettledCNEntity.ReturnMesage = objSqlParameter[5].Value.ToString();
            return i;

        }

        public DataSet getClosedSchemeSettlementDetails(long UserID, string RequestNumber)
        {
            SqlParameter[] param = new SqlParameter[2];
            param[0] = new SqlParameter("@UserID", UserID);
            param[1] = new SqlParameter("@RequestNumber", RequestNumber);
            return ObjSchemeSettle.getClosedSchemeSettlementDetails(param);
        }

    }
}
