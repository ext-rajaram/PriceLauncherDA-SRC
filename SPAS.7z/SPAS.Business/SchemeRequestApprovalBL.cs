﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SPAS.Data;
using System.Data.SqlClient;
using System.Data;
using SPAS.Business.Entity;

namespace SPAS.Business
{
    public class SchemeRequestApprovalBL
    {
        SchemeRequestApprovalDL ObjScheme = new SchemeRequestApprovalDL();
        public DataSet getSchemeRequest_details_for_View(Int64 RequestID)
        {
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@RequestID", RequestID);
            return ObjScheme.getSchemeRequest_details_for_View(param);
         
        }

        public bool Approve_Scheme_Request(ref SchemeRequestAppEntity objReqappEntity)
        {
            SqlParameter[] param = new SqlParameter[8];
            param[0] = new SqlParameter("@RequestID", objReqappEntity.RequestID);
            param[1] = new SqlParameter("@UserID", objReqappEntity.UserID);
            param[2] = new SqlParameter("@RoleName", objReqappEntity.RoleName);
            param[3] = new SqlParameter("@IsApproved", objReqappEntity.IsApproved);
            param[4] = new SqlParameter("@IsAdhoc", objReqappEntity.IsAdhoc);
            param[5] = new SqlParameter("@ApproverComments", objReqappEntity.ApproverComments);
            param[6] = new SqlParameter("@ReturnCode", objReqappEntity.ReturnCode);
            param[6].Direction = ParameterDirection.Output;
            param[7] = new SqlParameter("@ReturnMessage", SqlDbType.VarChar, 500);
            param[7].Direction = ParameterDirection.Output;
          int i =   ObjScheme.Approve_Scheme_Request(param);
          objReqappEntity.ReturnCode = Convert.ToInt16(param[6].Value);
          objReqappEntity.ReturnMesage = param[7].Value.ToString();

          if (Convert.ToInt16(param[6].Value) == 0)
              return true;
          else return false;
        }
    }
}
