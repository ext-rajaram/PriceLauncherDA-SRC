﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using SPAS.Data;
using System.Data.SqlClient;

namespace SPAS.Business
{
    public class ReportBL
    {
        ReportDL objReportDL = new ReportDL();
        public DataSet getBGDetail()
        {

            return objReportDL.getBGDetail();

        }

        public DataSet getReportDetail(string Fromdt, string Todt, int BGID )
        {

            SqlParameter[] param = new SqlParameter[3];
            param[0] = new SqlParameter("@Fromdt", Fromdt);
            param[1] = new SqlParameter("@Todt", Todt);
            param[2] = new SqlParameter("@BGID", BGID);
            return objReportDL.getReportDetail(param);

        }
    }
}
