﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using SPAS.Data;
using System.Data.SqlClient;

namespace SPAS.Business
{
    public class RolesBL
    {

        public SqlDataReader GetRoleByUserId(long UserId)
        {
            RolesDL oRoelDL = new RolesDL();

            return oRoelDL.GetRoleByUserId(UserId);
        }

        public DataSet SelectAllRolesbyUserId(long UserId)
        {
            RolesDL oRoelDL = new RolesDL();

            return oRoelDL.SelectAllRolesbyUserId(UserId);
        }

        public DataTable SelectAllRoles()
        {
            RolesDL oRoelDL = new RolesDL();

            return oRoelDL.SelectAllRoles();
        }


    }
}
