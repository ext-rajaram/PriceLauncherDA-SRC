﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SPAS.Data;
using System.Data.SqlClient;
using System.Data;
using SPAS.Business.Entity;

namespace SPAS.Business
{
    public class SchemeSettlementApprovalBL
    {
        SchemeSettlementApprovalDL ObjSchemeSettel = new SchemeSettlementApprovalDL();
        public DataSet getSchemeSettlementdetailsforApprover(long UserID)
        {
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@UserID", UserID);
            return ObjSchemeSettel.getSchemeSettlementdetailsforApprover(param);
        }

        public bool Approve_Scheme_Settlement_Request(ref SchemeSettlementEntity objReqappEntity)
        {
            SqlParameter[] param = new SqlParameter[7];
            param[0] = new SqlParameter("@SettlementID", objReqappEntity.SettlementID);
            param[1] = new SqlParameter("@UserID", objReqappEntity.UserID);
            param[2] = new SqlParameter("@RoleName", objReqappEntity.RoleName);
            param[3] = new SqlParameter("@IsApproved", objReqappEntity.IsApproved);
            param[4] = new SqlParameter("@ApproverComments", objReqappEntity.ApproverComments);
            param[5] = new SqlParameter("@ReturnCode", objReqappEntity.ReturnCode);
            param[5].Direction = ParameterDirection.Output;
            param[6] = new SqlParameter("@ReturnMessage", SqlDbType.VarChar, 500);
            param[6].Direction = ParameterDirection.Output;
            int i = ObjSchemeSettel.Approve_Scheme_Settlement_Request(param);
            objReqappEntity.ReturnCode = Convert.ToInt16(param[5].Value);
            objReqappEntity.ReturnMesage = param[6].Value.ToString();

            if (Convert.ToInt16(param[5].Value) == 0)
                return true;
            else return false;
        }

        public DataSet getSchemeSettlementCustomer(long SettlementID)
        {
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@SettlementID", SettlementID);
            return ObjSchemeSettel.getSchemeSettlementCustomer(param);
        }

    }
}
