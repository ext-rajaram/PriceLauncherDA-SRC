﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SPAS.Business.Entity
{
    public class RoleEntity
    {
        public int RoleID { get; set; }
        public int RoleName { get; set; }
        public int CreatedBy { get; set; }
        public int ModifiedBy { get; set; }
        public int ModuleName { get; set; }
        public int ReturnCode { get; set; }
        public string ReturnMesage { get; set; }       
    }
}
