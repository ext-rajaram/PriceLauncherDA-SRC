﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
namespace SPAS.Business.Entity
{
    public class RequestApprovalEntity
    {
        public static DataTable CreateRequestApproval
        {
            get { return (DataTable)HttpContext.Current.Session["@CreateRequestApproval"]; }
            set { HttpContext.Current.Session["@CreateRequestApproval"] = value; }
        }
        public Int64 RequestID { get; set; }
        public int AppFlag { get; set; }
        public int StatusId { get; set; }
        public string ApprovalRemarks { get; set; }
        public long CreatedBy { get; set; }
        public bool RequestChangedByApprover { get; set; }
        public int ReturnCode { get; set; }
        
        public string xmldetails { get; set; }
        public string ReturnMesage { get; set; }

    
    }
}
