﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SPAS.Business.Entity
{
   public class MagEntity
    {

        public int IsEditMode { get; set; }
        public string MagCode { get; set; }
        public string MagDescription { get; set; }
        public int CreatedBy { get; set; }
        public int ModifiedBy { get; set; }
        public int ReturnCode { get; set; }
        public string ReturnMesage { get; set; }
        public int MagID { get; set; }
       
       //SAG///
       public int SagID { get; set; }       
        public string SagDescription { get; set; }
        public int BUId { get; set; }

       ///SAG//
       ///
       


       ///Group2COD//
       ///
        public string Goup2 { get; set; }
    }
}
