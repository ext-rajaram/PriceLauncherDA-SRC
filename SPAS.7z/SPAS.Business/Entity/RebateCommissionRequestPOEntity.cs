﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

namespace SPAS.Business.Entity
{
    public class RebateCommissionRequestPOEntity
    {

        public Int64 RequestID { get; set; }

        public string PurchaseOrderDate { get; set; }

        public string PurchaseOrderNo { get; set; }

        public int CreatedBy { get; set; }

        public int ReturnCode { get; set; }

        public string ReturnMesage { get; set; }

        public string SettleAttachFileName
        {
            get { return (string)HttpContext.Current.Session["@SettleAttachFileName"]; }
            set { HttpContext.Current.Session["@SettleAttachFileName"] = value; }
        }

        public string AttachFileNameRebateCommiRequestPO
        {
            get { return (string)HttpContext.Current.Session["@AttachFileNameRebateCommiRequestPO"]; }
            set { HttpContext.Current.Session["@AttachFileNameRebateCommiRequestPO"] = value; }
        }
        public string AttachFileTypeRebateCommiRequestPO
        {
            get { return (string)HttpContext.Current.Session["@AttachFileTypeRebateCommiRequestPO"]; }
            set { HttpContext.Current.Session["@AttachFileTypeRebateCommiRequestPO"] = value; }
        }

        public byte[] AttachFileRebateCommiRequestPO
        {
            get { return (byte[])HttpContext.Current.Session["@AttachFileRebateCommiRequestPO"]; }
            set { HttpContext.Current.Session["@AttachFileRebateCommiRequestPO"] = value; }
        }
    }
}
