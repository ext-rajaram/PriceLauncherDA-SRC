﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SPAS.Business.Entity
{
    public class MarketingManagerBUMappingEntity
    {
        public int IsEditMode { get; set; }
        public Int64 MktMgrId { get; set; }
        public Int64 BUId { get; set; }
        public int CreatedBy { get; set; }
        public int ModifiedBy { get; set; }
        public int ReturnCode { get; set; }
        public string ReturnMesage { get; set; }   
    }
}
