﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SPAS.Business.Entity
{
    public class SchemeSettledCNEntity
    {
        public Int64 SettlementID { get; set; }
        public string CreditNoteNo { get; set; }
        public string CreditNoteDate { get; set; }
        public int CreatedBy { get; set; }
        public int ReturnCode { get; set; }
        public string ReturnMesage { get; set; } 
    }
}
