﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SPAS.Business.Entity
{
   public class ExchangeRate
    {
       public int year { get; set; }
       public int month { get; set;}
       public float rate { get; set;}
       public int RateID { get; set;}
       public int IsEditMode { get; set; }
       
       public int ReturnCode { get; set; }
       public string ReturnMesage { get; set; }
    }
}
