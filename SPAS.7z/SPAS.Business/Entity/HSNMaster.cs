﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SPAS.Business.Entity
{
    public class HSNMaster
    {
        public Int64 HSNId { get; set; }
        public string HSN { get; set; }
        public float TaxPercentage { get; set; }
        public int IsEditMode { get; set; }

        public int ReturnCode { get; set; }
        public string ReturnMesage { get; set; }
    }
}
