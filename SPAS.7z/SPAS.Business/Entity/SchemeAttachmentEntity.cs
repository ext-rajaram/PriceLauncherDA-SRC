﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
namespace SPAS.Business.Entity
{
    public class SchemeAttachmentEntity
    {
       
            public Int64 ID { get; set; }
            public Int64 RequestID { get; set; }
            public int ReturnCode { get; set; }
            public string ReturnMesage { get; set; }
            public string SchemeDescription { get; set; }
            public string AttachmentCalculation { get; set; }

            public string AttachFileName
            {
                get { return (string)HttpContext.Current.Session["@AttachFileName"]; }
                set { HttpContext.Current.Session["@AttachFileName"] = value; }
            }

            public string AttachFileType
            {
                get { return (string)HttpContext.Current.Session["@AttachFileType"]; }
                set { HttpContext.Current.Session["@AttachFileType"] = value; }
            }

            public byte[] AttachFile
            {
                get { return (byte[])HttpContext.Current.Session["@AttachFile"]; }
                set { HttpContext.Current.Session["@AttachFile"] = value; }
            }

            public string ExpectedSales { get; set; }
            public string ExpectedPayout { get; set; }
            public string PercentagePayout { get; set; }

    }
}
