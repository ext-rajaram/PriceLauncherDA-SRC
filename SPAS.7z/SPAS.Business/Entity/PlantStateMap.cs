﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SPAS.Business.Entity
{
  public  class PlantStateMap
    {


        public int IsEditMode { get; set; }
        public string Plant { get; set; }
        public int Stateid { get; set; }
        public int CreatedBy { get; set; }
        public int ModifiedBy { get; set; }
        public int ReturnCode { get; set; }
        public string ReturnMesage { get; set; }
        public int plantID { get; set; }
    }
}
