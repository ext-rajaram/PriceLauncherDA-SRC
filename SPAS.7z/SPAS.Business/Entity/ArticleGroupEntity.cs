﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SPAS.Business.Entity
{
    public  class ArticleGroupEntity
    {

        public int IsEditMode { get; set; }
        public string AgCode { get; set; }
        public string AgDescription { get; set; }
        public int CreatedBy { get; set; }
        public int ModifiedBy { get; set; }
        public int ReturnCode { get; set; }
        public string ReturnMesage { get; set; }
        public int AgID { get; set; }
    }
}
