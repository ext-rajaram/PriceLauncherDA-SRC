﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SPAS.Business.Entity
{
   public class SchemeRequestAppEntity
    {
        public Int64 RequestID;
        public int UserID;
        public string  RoleName;
        public int IsApproved;
        public int IsAdhoc;
        public string ApproverComments;
        public int ReturnCode { get; set; }
        public string ReturnMesage { get; set; }
    }
}
