﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
namespace SPAS.Business.Entity
{
    public class SchemeRequestEntity
    {
        public static DataTable CreateRequest
        {
            get { return (DataTable)HttpContext.Current.Session["@CreateSchemeRequest"]; }
            set { HttpContext.Current.Session["@CreateSchemeRequest"] = value; }
        }
            public Int64 RequestID { get; set; }
            public int RegionID { get; set; }
            public Int64 UserID { get; set; }
            public long CreatedBy { get; set; }
            public int ReturnCode { get; set; }

            public string RequestList { get; set; }
            public string Regions { get; set; }
           
            public string Group2 { get; set; }
            public Int32 ChannelId { get; set; }
            public string Branch { get; set; }
            public string Customer { get; set; }
            
            public string BG { get; set; }
            public int BGId { get; set; }
            public string BU { get; set; }
            public int BUId { get; set; }
            public string SAG { get; set; }
            public int SAGId { get; set; }
            public string Product { get; set; }
            public string FromDate { get; set; }
            public string ToDate { get; set; }
            public string xmldetails { get; set; }
            public string ReturnMessage { get; set; }
            public bool IsPrimary { get; set; }
            public int AdhocType { get; set; }
            public string Rolename { get; set; }
            public string StandardSchemes { get; set; }
           
            public int Statusid { get; set; }
            
            public string ReturnMesage { get; set; }
            //public string UploadName { get; set; }
            //public byte[] UploadFile { get; set; }
            //public string UploadFileType { get; set; }
            public string RequesterComments { get; set; }

            public int IsPriorPeriod { get; set; }
            public string RollOutFileName { get; set; }
            public static string AttachFileName
            {
                get { return (string)HttpContext.Current.Session["@AttachFileName"]; }
                set { HttpContext.Current.Session["@AttachFileName"] = value; }
            }
            public static string AttachFileType
            {
                get { return (string)HttpContext.Current.Session["@AttachFileType"]; }
                set { HttpContext.Current.Session["@AttachFileType"] = value; }
            }

            public static byte[] AttachFile
            {
                get { return (byte[])HttpContext.Current.Session["@AttachFile"]; }
                set { HttpContext.Current.Session["@AttachFile"] = value; }
            }


            public static string AttachFileNameRepope
            {
                get { return (string)HttpContext.Current.Session["@AttachFileNameRepope"]; }
                set { HttpContext.Current.Session["@AttachFileNameRepope"] = value; }
            }
            public static string AttachFileTypeRepope
            {
                get { return (string)HttpContext.Current.Session["@AttachFileTypeRepope"]; }
                set { HttpContext.Current.Session["@AttachFileTypeRepope"] = value; }
            }

            public static byte[] AttachFileRepope
            {
                get { return (byte[])HttpContext.Current.Session["@AttachFileRepope"]; }
                set { HttpContext.Current.Session["@AttachFileRepope"] = value; }
            }

            public string AttachFileNameReopenv
            {
                get { return (string)HttpContext.Current.Session["@AttachFileNameReopenv"]; }
                set { HttpContext.Current.Session["@AttachFileNameReopenv"] = value; }
            }
            public string AttachFileTypeReopenv
            {
                get { return (string)HttpContext.Current.Session["@AttachFileTypeReopenv"]; }
                set { HttpContext.Current.Session["@AttachFileTypeReopenv"] = value; }
            }

            public byte[] AttachFileReopenv
            {
                get { return (byte[])HttpContext.Current.Session["@AttachFileReopenv"]; }
                set { HttpContext.Current.Session["@AttachFileReopenv"] = value; }
            }

    }
}
