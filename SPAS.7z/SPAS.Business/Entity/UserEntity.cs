﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SPAS.Business.Entity
{
    public class UserEntity
    {
        public Int64 UserId { get; set; }
        public string UserEmailID { get; set; }
        public int RoleID { get; set; }
        public int IsActive { get; set; }
        public int CreatedBy { get; set; }
        public int ModifiedBy { get; set; }
        public int ReturnCode { get; set; }
        public string ReturnMesage { get; set; }
        public string Username { get; set; }
        public string LoginID { get; set; }
        public int Region { get; set; }
        public int IsEditMode { get; set; }
        public string SECode { get; set; }


    }
}
