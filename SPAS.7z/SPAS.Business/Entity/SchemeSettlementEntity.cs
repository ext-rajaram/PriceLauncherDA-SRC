﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
namespace SPAS.Business.Entity
{
    public class SchemeSettlementEntity
    {
       
        public Int64 RequestID { get; set; }

        public int RegionID { get; set; }

        public long CreatedBy { get; set; }

        public long BGId { get; set; }

        public string Regions { get; set; }

        public string Group2 { get; set; }
        
        public string Customer { get; set; }

        public long CustomerCode { get; set; }

        public string CreditNoteNumber { get; set; }

        public decimal AmountSettled { get; set; }

        public string Remarks { get; set; }

        public string ReturnMessage { get; set; }

        public int ReturnCode { get; set; }

        public Int64 SettlementID { get; set; }

        public int UserID { get; set; }

        public string RoleName { get; set; }

        public int IsApproved { get; set; }

        public string ApproverComments { get; set; }

        public string ReturnMesage { get; set; }
        
        public string SettleAttachFileName
        {
            get { return (string)HttpContext.Current.Session["@SettleAttachFileName"]; }
            set { HttpContext.Current.Session["@SettleAttachFileName"] = value; }
        }

        public string SettleAttachFileType
        {
            get { return (string)HttpContext.Current.Session["@SettleAttachFileType"]; }
            set { HttpContext.Current.Session["@SettleAttachFileType"] = value; }
        }

        public byte[] SettleAttachFile
        {
            get { return (byte[])HttpContext.Current.Session["@SettleAttachFile"]; }
            set { HttpContext.Current.Session["@SettleAttachFile"] = value; }
        }
       

    }
}
