﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SPAS.Business.Entity
{
    public  class BusinessGroupEntity
    {

        public int IsEditMode { get; set; }
        public string BgCode { get; set; }
        public string BgDescription { get; set; }
        public int CreatedBy { get; set; }
        public int ModifiedBy { get; set; }
        public int ReturnCode { get; set; }
        public string ReturnMesage { get; set; }
        public int BgID { get; set; }
    }
}
