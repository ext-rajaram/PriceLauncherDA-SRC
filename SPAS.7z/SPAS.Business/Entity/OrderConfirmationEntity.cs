﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SPAS.Business.Entity
{
    public class OrderConfirmationEntity
    {
        public Int64 OrderConfirmationID { get; set; }
        public Int64 RequestID { get; set; }
        public int RequestLineNo { get; set; }
        public Int64 MaterialID { get; set; }
        public string Plant { get; set; }
        public Int64 ShipToCode { get; set; }
        public int ConfirmedQty { get; set; }
        public string RequestedDeliveryDate { get; set; }
        public long ModifyBy { get; set; }
        public DateTime ModifyOn { get; set; }
        public int ReturnCode { get; set; }
        public string ReturnMesage { get; set; }
        public int OrderdeskUserID { get; set; }
        
    }
}
