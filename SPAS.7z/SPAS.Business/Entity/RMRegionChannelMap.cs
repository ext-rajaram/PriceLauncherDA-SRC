﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SPAS.Business.Entity
{
  public  class RMRegionChannelMap
    {

      public int ID { get; set; }
      public int RegionID { get; set; }
      public int RMId { get; set; }
      public int channelID { get; set; }
      public int userID {get; set;}
      public int IsEditMode { get; set; }
      public int CreatedBy { get; set; }
      public int ModifiedBy { get; set; }
      public int ReturnCode { get; set; }
      public string ReturnMesage { get; set; }
    }
}
