﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SPAS.Business.Entity
{
   public class BusinessUnitEntity
    {

        public int IsEditMode { get; set; }
        public string BuCode { get; set; }
        public string BuDescription { get; set; }
        public int CreatedBy { get; set; }
        public int ModifiedBy { get; set; }
        public int ReturnCode { get; set; }
        public string ReturnMesage { get; set; }
        public int BuID { get; set; }
        public int BgID { get; set; }


       // New Channel
        public string Channel { get; set; }
        public int ChannelID { get; set; }

       ///Group to channel mapping

        public string group {get; set;}
        public string EditGroup { get; set; }
        
    }
}
