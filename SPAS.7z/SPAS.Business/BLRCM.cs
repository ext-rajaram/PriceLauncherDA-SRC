﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SPAS.Data;
using System.Data;
using System.Data.SqlClient;
using SPAS.Business.Entity;

namespace SPAS.Business
{
   public class BLRCM
    {

       DLRCM objdlrcm = new DLRCM();

        public DataSet GetChannellist()
        {
            return objdlrcm.Get_Channel();
        }

        public DataSet GetRegions()
        {

            return objdlrcm.Get_Region();
        }
        public DataSet Get_SearchRCMmap(int stregion, int strchannel)
        {
            SqlParameter[] objSqlParameter = new SqlParameter[2];
            objSqlParameter[0] = new SqlParameter("@SearchRegion", stregion);
            objSqlParameter[1] = new SqlParameter("@SearchChannel", strchannel);
            return objdlrcm.Get_RCMmapSearch(objSqlParameter);

        }

        public DataSet GetRCMmap()
        {
            return objdlrcm.Get_RCMmap();
        }
        public DataSet GetRCMusers()
        {

            return objdlrcm.GetRCMusers();
        }
        public DataSet Get_RCMforEdit(ref RCMRegionChannelMap Objbgentity)
        {
            SqlParameter[] objSqlParameter = new SqlParameter[1];
            objSqlParameter[0] = new SqlParameter("@ID", Objbgentity.ID);
            return objdlrcm.Get_RCMmapEDIT(objSqlParameter);

        }

        public bool Insert_NewRCmMap(ref RCMRegionChannelMap objrmmap)
        {
            SqlParameter[] objSqlParameter = new SqlParameter[8];
            objSqlParameter[0] = new SqlParameter("@ReturnCode", objrmmap.ReturnCode);
            objSqlParameter[0].Direction = ParameterDirection.Output;
            objSqlParameter[1] = new SqlParameter("@ReturnMessage", SqlDbType.VarChar, 500);
            objSqlParameter[1].Direction = ParameterDirection.Output;
            objSqlParameter[2] = new SqlParameter("@IsEditMode", objrmmap.IsEditMode);
            objSqlParameter[3] = new SqlParameter("@RegionID", objrmmap.RegionID);
            objSqlParameter[4] = new SqlParameter("@channelID", objrmmap.channelID);
            objSqlParameter[5] = new SqlParameter("@createdby", objrmmap.CreatedBy);
            objSqlParameter[6] = new SqlParameter("@RCMID", objrmmap.RCMId);
            objSqlParameter[7] = new SqlParameter("@ID", objrmmap.ID);

            int i = objdlrcm.Insert_RCMMapping(objSqlParameter);
            objrmmap.ReturnCode = Convert.ToInt16(objSqlParameter[0].Value);
            objrmmap.ReturnMesage = objSqlParameter[1].Value.ToString();
            if (Convert.ToInt16(objSqlParameter[0].Value) == 0)
                return true;
            else return false;

        }
    }
}
