﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SPAS.Data;
using System.Data.SqlClient;
using System.Data;
using SPAS.Business.Entity;


namespace SPAS.Business
{
    public class RequestApprovalBL
    {
        RequestApprovalDL ObjReqApprovalDL = new RequestApprovalDL();
        public DataSet getrequestCompletedetailsforApproval(Int64 RequestID, long UserID, string UserRoleName)
        {
            SqlParameter[] param = new SqlParameter[3];
            param[0] = new SqlParameter("@RequestID", RequestID);
            param[1] = new SqlParameter("@UserID", UserID);
            param[2] = new SqlParameter("@UserRoleName", UserRoleName);
            return ObjReqApprovalDL.getrequestCompletedetailsforApproval(param);
        }

        public DataSet getApprovedRequestByRequestId(Int64 RequestID, long UserID)
        {
            SqlParameter[] param = new SqlParameter[2];
            param[0] = new SqlParameter("@RequestID", RequestID);
            param[1] = new SqlParameter("@UserID", UserID);
            
            return ObjReqApprovalDL.getApprovedRequestByRequestId(param);
        }

        public bool Save_RequestApprovalDetails(ref Entity.RequestApprovalEntity objReqEntity)
        {

            SqlParameter[] objSqlParameter = new SqlParameter[7];

            objSqlParameter[0] = new SqlParameter("@RequestId", objReqEntity.RequestID);
            objSqlParameter[1] = new SqlParameter("@CreatedBy", objReqEntity.CreatedBy);
            objSqlParameter[2] = new SqlParameter("@xmldetails", objReqEntity.xmldetails);
            objSqlParameter[3] = new SqlParameter("@Remarks", objReqEntity.ApprovalRemarks);
            objSqlParameter[4] = new SqlParameter("@ReqChangedByApp", objReqEntity.RequestChangedByApprover);
            objSqlParameter[5] = new SqlParameter("@ReturnCode", objReqEntity.ReturnCode);
            objSqlParameter[5].Direction = ParameterDirection.Output;
            objSqlParameter[6] = new SqlParameter("@ReturnMessage", SqlDbType.VarChar, 500);
            objSqlParameter[6].Direction = ParameterDirection.Output;

            int i = ObjReqApprovalDL.Save_RequestApprovalDetails(objSqlParameter);
            objReqEntity.ReturnCode = Convert.ToInt16(objSqlParameter[5].Value);
            objReqEntity.ReturnMesage = objSqlParameter[6].Value.ToString();
            if (Convert.ToInt16(objSqlParameter[5].Value) == 0)
                return true;
            else return false;

        }

        public bool Save_RequestApprovalByPH_PC(ref Entity.RequestApprovalEntity objReqEntity)
        {

            SqlParameter[] objSqlParameter = new SqlParameter[7];

            objSqlParameter[0] = new SqlParameter("@RequestId", objReqEntity.RequestID);
            objSqlParameter[1] = new SqlParameter("@CreatedBy", objReqEntity.CreatedBy);
            objSqlParameter[2] = new SqlParameter("@AppFlag", objReqEntity.AppFlag);
            objSqlParameter[3] = new SqlParameter("@Status", objReqEntity.StatusId);
            objSqlParameter[4] = new SqlParameter("@Remarks", objReqEntity.ApprovalRemarks);
            objSqlParameter[5] = new SqlParameter("@ReturnCode", objReqEntity.ReturnCode);
            objSqlParameter[5].Direction = ParameterDirection.Output;
            objSqlParameter[6] = new SqlParameter("@ReturnMessage", SqlDbType.VarChar, 500);
            objSqlParameter[6].Direction = ParameterDirection.Output;

            int i = ObjReqApprovalDL.Save_RequestApprovalByPH_PC(objSqlParameter);
            objReqEntity.ReturnCode = Convert.ToInt16(objSqlParameter[5].Value);
            objReqEntity.ReturnMesage = objSqlParameter[6].Value.ToString();
            if (Convert.ToInt16(objSqlParameter[5].Value) == 0)
                return true;
            else return false;

        }

        

      

        public DataTable getPriceDownload(ref RequestApprovalEntity objReqEntity)
        {
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@RequestID", objReqEntity.RequestID);
            return ObjReqApprovalDL.getPriceDownload(param);
        }

        public DataSet getApprovedRequestHeader_for_Approver(long Userid, DateTime dtFromData, DateTime dtToDate, string strSearch)
        {
            SqlParameter[] param = new SqlParameter[4];
            param[0] = new SqlParameter("@Userid", Userid);
            param[1] = new SqlParameter("@FromDate", dtFromData);
            param[2] = new SqlParameter("@ToDate", dtToDate);
            param[3] = new SqlParameter("@Search", strSearch);
            return ObjReqApprovalDL.getApprovedRequestHeader_for_Approver(param);
        }
    }
}
