﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SPAS.Data;
using System.Data.SqlClient;
using System.Data;
using SPAS.Business.Entity;

namespace SPAS.Business
{
    public class SchemeReportBL
    {
        SchemeReportDL ObjScheme = new SchemeReportDL();
        public DataSet getReportSchemerequestdetails(long CreatedBy, string RequestNumber, string Role)
        {
            SqlParameter[] param = new SqlParameter[3];
            param[0] = new SqlParameter("@CreatedBy", CreatedBy);
            param[1] = new SqlParameter("@RequestNumber", RequestNumber);
            param[2] = new SqlParameter("@Role", Role);
            
            return ObjScheme.getReportSchemerequestdetails(param);
        }

        public DataSet getReportSchemeFinance(int UserID, string RequestNumber, string fromdate, string todate)
        {
            SqlParameter[] param = new SqlParameter[4];
            param[0] = new SqlParameter("@RequestNumber", RequestNumber);
            param[1] = new SqlParameter("@FromDate", fromdate);
            param[2] = new SqlParameter("@ToDate", todate);
            param[3] = new SqlParameter("@UserID", UserID);

            return ObjScheme.getReportSchemeFinance(param);
        }

        public DataSet getApprovedListofSchemesReport(string RequestNumber, string fromdate, string todate, string RoleId, int UserID)
        {
            SqlParameter[] param = new SqlParameter[5];
            param[0] = new SqlParameter("@RequestNumber", RequestNumber);
            param[1] = new SqlParameter("@FromDate", fromdate);
            param[2] = new SqlParameter("@ToDate", todate);
            param[3] = new SqlParameter("@RoleId", RoleId);
            param[4] = new SqlParameter("@UserID", UserID);

            return ObjScheme.getApprovedListofSchemesReport(param);
        }

        public DataSet getApprovedListofSchemeSettlementReport(string RequestNumber, string SettlementSerialNo, string fromdate, string todate, int UserID)
        {
            SqlParameter[] param = new SqlParameter[5];
            param[0] = new SqlParameter("@RequestNumber", RequestNumber);
            param[1] = new SqlParameter("@SettlementSerialNo", SettlementSerialNo);
            param[2] = new SqlParameter("@FromDate", fromdate);
            param[3] = new SqlParameter("@ToDate", todate);
            param[4] = new SqlParameter("@UserID", UserID);

            return ObjScheme.getApprovedListofSchemeSettlementReport(param);
        }

        public DataSet getApprovedListofSchemeSettlementReportAO(string RequestNumber, string SettlementSerialNo, string fromdate, string todate, int UserID)
        {
            SqlParameter[] param = new SqlParameter[5];
            param[0] = new SqlParameter("@RequestNumber", RequestNumber);
            param[1] = new SqlParameter("@SettlementSerialNo", SettlementSerialNo);
            param[2] = new SqlParameter("@FromDate", fromdate);
            param[3] = new SqlParameter("@ToDate", todate);
            param[4] = new SqlParameter("@UserID", UserID);

            return ObjScheme.getApprovedListofSchemeSettlementReportAO(param);
        }

    }
}
