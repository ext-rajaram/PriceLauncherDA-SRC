﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SPAS.Data;
using System.Data.SqlClient;
using System.Data;


namespace SPAS.Business
{
   public class RequestBL
    {
     

       RequestDL ObjReqDL = new RequestDL();
        public DataSet getsoldtocustomer(ref RequestEntity objReqEntity)
        {
            SqlParameter[] param = new SqlParameter[3];
            param[0] = new SqlParameter("@RegionID", objReqEntity.RegionID);
            param[1] = new SqlParameter("@SECode", objReqEntity.SECode);
            param[2] = new SqlParameter("@Rolename", objReqEntity.Rolename);
            return ObjReqDL.getsoldtocustomer(param);
        }

      

        public DataSet getshiptocustomer(ref RequestEntity objReqEntity)
        {
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@SoldTo", objReqEntity.SoldTo);
            return ObjReqDL.getshiptocustomer(param);
        }
        public DataSet getBranchPlant()
        {
            return ObjReqDL.getBranchPlant();
        }

        public DataSet getApprovedItem(Int64 RequestId)
        {
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@RequestId", RequestId);
            
            return ObjReqDL.getApprovedItem(param);
        }
       
        public DataSet getSoldToPartyRegion(Int64 SoldToID)
        {
            return ObjReqDL.getSoldToPartyRegion(SoldToID);
        }
         public DataSet getChannelDetails( Int64 ShiptoCustomerID)
        {
            return ObjReqDL.getChannelDetails(ShiptoCustomerID);
        }

         public DataSet getMaterialSearchdata(ref RequestEntity objReqEntity)
         {
             SqlParameter[] param = new SqlParameter[6];
             param[0] = new SqlParameter("@Plant", objReqEntity.Plant);
             param[1] = new SqlParameter("@Material", objReqEntity.Material);
             param[2] = new SqlParameter("@MaterialDescription", objReqEntity.MaterialDescription);
             param[3] = new SqlParameter("@BG", objReqEntity.BGCode);
             param[4] = new SqlParameter("@BU", objReqEntity.BUCode);
             param[5] = new SqlParameter("@SAG", objReqEntity.SAGCode);
             return ObjReqDL.getMaterialSearchdata(param);
         }

         public bool Save_RequestDetails(ref RequestEntity objReqEntity)
         {

            SqlParameter[] objSqlParameter = new SqlParameter[15];
            objSqlParameter[0] = new SqlParameter("@SoldToParty", objReqEntity.SoldTo);
            objSqlParameter[1] = new SqlParameter("@Plant", objReqEntity.Plant);
            objSqlParameter[2] = new SqlParameter("@ValidityDate", objReqEntity.ValidityDate);
            objSqlParameter[3] = new SqlParameter("@PurchaseOrderDate", objReqEntity.PurchaseOrderDate);
            objSqlParameter[4] = new SqlParameter("@RequestedDeliveryDate", objReqEntity.RequestedDeliveryDate);
            objSqlParameter[5] = new SqlParameter("@ReasonforRequest", objReqEntity.ReasonforRequest);
            objSqlParameter[6] = new SqlParameter("@PurchaseOrder", objReqEntity.PurchaseOrder);
            objSqlParameter[7] = new SqlParameter("@CreatedBy", objReqEntity.CreatedBy);
            objSqlParameter[8] = new SqlParameter("@xmldetails", objReqEntity.xmldetails);
            objSqlParameter[9] = new SqlParameter("@RegionCode", objReqEntity.RegionCode);
            objSqlParameter[10] = new SqlParameter("@GROUP2", objReqEntity.GROUP2);
            objSqlParameter[11] = new SqlParameter("@ReturnCode", objReqEntity.ReturnCode);
            objSqlParameter[11].Direction = ParameterDirection.Output;
            objSqlParameter[12] = new SqlParameter("@ReturnMessage", SqlDbType.VarChar, 500);
            objSqlParameter[12].Direction = ParameterDirection.Output;
            objSqlParameter[13] = new SqlParameter("@IsExistingCustomer", objReqEntity.IsExistingCustome);
            objSqlParameter[14] = new SqlParameter("@NewCustomerName", objReqEntity.NewCustomeName);
            int i = ObjReqDL.Save_RequestDetails(objSqlParameter);
             objReqEntity.ReturnCode = Convert.ToInt16(objSqlParameter[11].Value);
             objReqEntity.ReturnMesage = objSqlParameter[12].Value.ToString();
             if (Convert.ToInt16(objSqlParameter[11].Value) == 0)
                 return true;
             else return false;

         }

         public DataSet getrequestdetails(long CreatedBy, string RequestNumber)
         {
             SqlParameter[] param = new SqlParameter[2];
             param[0] = new SqlParameter("@CreatedBy", CreatedBy);
             param[1] = new SqlParameter("@RequestNumber", RequestNumber);
             return ObjReqDL.getrequestdetails(param);
         }
         public DataSet getrequestCompletedetailsforView(Int64 RequestID)
         {
             SqlParameter[] param = new SqlParameter[1];
             param[0] = new SqlParameter("@RequestID", RequestID);
             return ObjReqDL.getrequestCompletedetailsforView(param);
         }

         public DataSet getOrderConfirmationData(Int64 RequestID)
         {
             SqlParameter[] param = new SqlParameter[1];
             param[0] = new SqlParameter("@RequestID", RequestID);
             return ObjReqDL.getOrderConfirmationData(param);
         }

         public DataSet getpendingforapprovalrequestHeader_for_Approver(long Userid)
         {
             SqlParameter[] param = new SqlParameter[1];
             param[0] = new SqlParameter("@Userid", Userid);
             return ObjReqDL.getpendingforapprovalrequestHeader_for_Approver(param);
         }

      

       public bool Save_Request_Order_Confirmation(ref RequestEntity objReqEntity)
         {

             SqlParameter[] objSqlParameter = new SqlParameter[8];

             objSqlParameter[0] = new SqlParameter("@RequestId", objReqEntity.RequestID);
             objSqlParameter[1] = new SqlParameter("@ReturnCode", objReqEntity.ReturnCode);
             objSqlParameter[1].Direction = ParameterDirection.Output;
             objSqlParameter[2] = new SqlParameter("@ReturnMessage", SqlDbType.VarChar, 500);
             objSqlParameter[2].Direction = ParameterDirection.Output;
             objSqlParameter[3] = new SqlParameter("@SAPSalesOrderNumber", objReqEntity.SAPSalesOrderNumber);
             objSqlParameter[5] = new SqlParameter("@OldRequestHeaderStatusid", objReqEntity.RequestHeaderStatusid);
             objSqlParameter[6] = new SqlParameter("@SOId", objReqEntity.SOId);
             objSqlParameter[7] = new SqlParameter("@CreatedBy", objReqEntity.CreatedBy);

             int i = ObjReqDL.Save_Request_Order_Confirmation(objSqlParameter);
             objReqEntity.ReturnCode = Convert.ToInt16(objSqlParameter[1].Value);
             objReqEntity.ReturnMesage = objSqlParameter[2].Value.ToString();
             if (Convert.ToInt16(objSqlParameter[1].Value) == 0)
                 return true;
             else return false;

         }
       public DataTable getOrderDownload(ref RequestEntity objReqEntity)
       {
           SqlParameter[] param = new SqlParameter[2];
           param[0] = new SqlParameter("@RequestID", objReqEntity.RequestID);
           param[1] = new SqlParameter("@SOId", objReqEntity.SOId);
           return ObjReqDL.getOrderDownload(param);
       }

       public bool DeleteOrderConfirmation(ref Entity.OrderConfirmationEntity objOCEntity)
       {

           SqlParameter[] objSqlParameter = new SqlParameter[3];

           objSqlParameter[0] = new SqlParameter("@OrderConfirmationId", objOCEntity.OrderConfirmationID);
           objSqlParameter[1] = new SqlParameter("@ReturnCode", objOCEntity.ReturnCode);
           objSqlParameter[1].Direction = ParameterDirection.Output;
           objSqlParameter[2] = new SqlParameter("@ReturnMessage", SqlDbType.VarChar, 500);
           objSqlParameter[2].Direction = ParameterDirection.Output;


           int i = ObjReqDL.DeleteOrderConfirmation(objSqlParameter);
           objOCEntity.ReturnCode = Convert.ToInt16(objSqlParameter[1].Value);
           objOCEntity.ReturnMesage = objSqlParameter[2].Value.ToString();
           if (Convert.ToInt16(objSqlParameter[1].Value) == 0)
               return true;
           else return false;

       }

       public bool Save_OrderConfirmationRequest(ref Entity.OrderConfirmationEntity objOCEntity)
       {

           SqlParameter[] objSqlParameter = new SqlParameter[9];

           objSqlParameter[0] = new SqlParameter("@RequestId", objOCEntity.RequestID);
           objSqlParameter[1] = new SqlParameter("@MaterialID", objOCEntity.MaterialID);
           objSqlParameter[2] = new SqlParameter("@Plant", objOCEntity.Plant);
           objSqlParameter[3] = new SqlParameter("@ShipToCode", objOCEntity.ShipToCode);
           objSqlParameter[4] = new SqlParameter("@ConfirmedQty", objOCEntity.ConfirmedQty);
           objSqlParameter[5] = new SqlParameter("@CreatedBy", objOCEntity.ModifyBy);
           objSqlParameter[6] = new SqlParameter("@RequestedDeliveryDate", objOCEntity.RequestedDeliveryDate);
           objSqlParameter[7] = new SqlParameter("@ReturnCode", objOCEntity.ReturnCode);
           objSqlParameter[7].Direction = ParameterDirection.Output;
           objSqlParameter[8] = new SqlParameter("@ReturnMessage", SqlDbType.VarChar, 500);
           objSqlParameter[8].Direction = ParameterDirection.Output;

           int i = ObjReqDL.Save_OrderConfirmationRequest(objSqlParameter);
           objOCEntity.ReturnCode = Convert.ToInt16(objSqlParameter[7].Value);
           objOCEntity.ReturnMesage = objSqlParameter[8].Value.ToString();
           if (Convert.ToInt16(objSqlParameter[7].Value) == 0)
               return true;
           else return false;

       }

       public bool SubmitOrderConfirmation(ref Entity.OrderConfirmationEntity objOCEntity)
       {

           SqlParameter[] objSqlParameter = new SqlParameter[4];

           objSqlParameter[0] = new SqlParameter("@RequestId", objOCEntity.RequestID);
           objSqlParameter[1] = new SqlParameter("@ReturnCode", objOCEntity.ReturnCode);
           objSqlParameter[1].Direction = ParameterDirection.Output;
           objSqlParameter[2] = new SqlParameter("@ReturnMessage", SqlDbType.VarChar, 500);
           objSqlParameter[2].Direction = ParameterDirection.Output;
           objSqlParameter[3] = new SqlParameter("@OrderdeskUserID", objOCEntity.OrderdeskUserID);
           


           int i = ObjReqDL.SubmitOrderConfirmation(objSqlParameter);
           objOCEntity.ReturnCode = Convert.ToInt16(objSqlParameter[1].Value);
           objOCEntity.ReturnMesage = objSqlParameter[2].Value.ToString();
           if (Convert.ToInt16(objSqlParameter[1].Value) == 0)
               return true;
           else return false;

       }

       public bool AssignSoldToForNewCustomer(ref RequestEntity objEntity)
       {

           SqlParameter[] objSqlParameter = new SqlParameter[4];

           objSqlParameter[0] = new SqlParameter("@RequestId", objEntity.RequestID);
           objSqlParameter[1] = new SqlParameter("@SoldToCode", objEntity.SoldTo);
           objSqlParameter[2] = new SqlParameter("@ReturnCode", objEntity.ReturnCode);
           objSqlParameter[2].Direction = ParameterDirection.Output;
           objSqlParameter[3] = new SqlParameter("@ReturnMessage", SqlDbType.VarChar, 500);
           objSqlParameter[3].Direction = ParameterDirection.Output;


           int i = ObjReqDL.AssignSoldToForNewCustomer(objSqlParameter);
           objEntity.ReturnCode = Convert.ToInt16(objSqlParameter[2].Value);
           objEntity.ReturnMesage = objSqlParameter[3].Value.ToString();
           if (Convert.ToInt16(objSqlParameter[2].Value) == 0)
               return true;
           else return false;

       }

       public DataSet get_OrderDesk_Details_OrderConfirmation(Int64 customerCode, Int64 RequestId)
       {
           SqlParameter[] param = new SqlParameter[2];
           param[0] = new SqlParameter("@customerCode", customerCode);
           param[1] = new SqlParameter("@RequestId", RequestId);

           return ObjReqDL.get_OrderDesk_Details_OrderConfirmation(param);
       }

       public int save_RebateCommissionRequestPODetails(ref Entity.RebateCommissionRequestPOEntity objPOEntity)
       {

           SqlParameter[] objSqlParameter = new SqlParameter[9];

           objSqlParameter[0] = new SqlParameter("@RequestID", objPOEntity.RequestID);
           objSqlParameter[1] = new SqlParameter("@PurchaseOrderNo", objPOEntity.PurchaseOrderNo);
           objSqlParameter[2] = new SqlParameter("@PurchaseOrderDate", objPOEntity.PurchaseOrderDate);
           objSqlParameter[3] = new SqlParameter("@CreatedBy", objPOEntity.CreatedBy);
           objSqlParameter[4] = new SqlParameter("@AttachFileName", objPOEntity.AttachFileNameRebateCommiRequestPO);
           if (objPOEntity.AttachFileRebateCommiRequestPO != null && objPOEntity.AttachFileRebateCommiRequestPO.Length > 0)
               objSqlParameter[5] = new SqlParameter("@AttachFile", SqlDbType.VarBinary, objPOEntity.AttachFileRebateCommiRequestPO.Length, ParameterDirection.Input, true, 0, 0, "AttachFile", DataRowVersion.Current, (System.Data.SqlTypes.SqlBinary)objPOEntity.AttachFileRebateCommiRequestPO);
           else
               objSqlParameter[5] = new SqlParameter("@AttachFile", SqlDbType.VarBinary, 8000, ParameterDirection.Input, true, 0, 0, "AttachFile", DataRowVersion.Current, DBNull.Value);

           objSqlParameter[6] = new SqlParameter("@AttachFileType", objPOEntity.AttachFileTypeRebateCommiRequestPO);
           objSqlParameter[7] = new SqlParameter("@ReturnCode", objPOEntity.ReturnCode);
           objSqlParameter[7].Direction = ParameterDirection.Output;
           objSqlParameter[8] = new SqlParameter("@ReturnMessage", SqlDbType.VarChar, 500);
           objSqlParameter[8].Direction = ParameterDirection.Output;

           int i = ObjReqDL.save_RebateCommissionRequestPODetails(objSqlParameter);
           objPOEntity.ReturnCode = Convert.ToInt16(objSqlParameter[7].Value);
           objPOEntity.ReturnMesage = objSqlParameter[8].Value.ToString();
           return i;

       }

    }
}
