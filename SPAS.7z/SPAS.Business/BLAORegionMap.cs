﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SPAS.Data;
using System.Data;
using System.Data.SqlClient;
using SPAS.Business.Entity;

namespace SPAS.Business
{
   public class BLAORegionMap
    {
       DLAORegionMap objAO = new DLAORegionMap();

       public DataSet GetChannellist()
       {
           return objAO.Get_Channel();
       }

       public DataSet GetRegions()
       {

           return objAO.Get_Region();
       }

       public DataSet Get_SearchAOmap(int stregion, int strchannel)
       {
           SqlParameter[] objSqlParameter = new SqlParameter[2];
           objSqlParameter[0] = new SqlParameter("@regionid", stregion);
           objSqlParameter[1] = new SqlParameter("@channelid", strchannel);
           return objAO.Get_AOmapSearch(objSqlParameter);

       }
       public DataSet GetAOmap()
       {
           return objAO.Get_AOmap();
       }

       public DataSet Get_users()
       {

           return objAO.GetAOusers();
       }

       public DataSet Get_AOforEdit(ref AORegionchannelMap Objbgentity)
       {
           SqlParameter[] objSqlParameter = new SqlParameter[1];
           objSqlParameter[0] = new SqlParameter("@ID", Objbgentity.ID);
           return objAO.Get_AOmapEDIT(objSqlParameter);

       }

       public bool Insert_NewAOMap(ref AORegionchannelMap objaomap)
       {
           SqlParameter[] objSqlParameter = new SqlParameter[8];
           objSqlParameter[0] = new SqlParameter("@ReturnCode", objaomap.ReturnCode);
           objSqlParameter[0].Direction = ParameterDirection.Output;
           objSqlParameter[1] = new SqlParameter("@ReturnMessage", SqlDbType.VarChar, 500);
           objSqlParameter[1].Direction = ParameterDirection.Output;
           objSqlParameter[2] = new SqlParameter("@IsEditMode", objaomap.IsEditMode);
           objSqlParameter[3] = new SqlParameter("@RegionID", objaomap.RegionID);
           objSqlParameter[4] = new SqlParameter("@channelID", objaomap.channelID);
           objSqlParameter[5] = new SqlParameter("@createdby", objaomap.CreatedBy);
           objSqlParameter[6] = new SqlParameter("@AOID", objaomap.AOId);
           objSqlParameter[7] = new SqlParameter("@ID", objaomap.ID);

           int i = objAO.Insert_AOMapping(objSqlParameter);
           objaomap.ReturnCode = Convert.ToInt16(objSqlParameter[0].Value);
           objaomap.ReturnMesage = objSqlParameter[1].Value.ToString();
           if (Convert.ToInt16(objSqlParameter[0].Value) == 0)
               return true;
           else return false;

       }

    }
}
