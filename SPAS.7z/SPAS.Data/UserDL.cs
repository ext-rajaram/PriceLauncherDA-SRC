﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace SPAS.Data
{
    public class UserDL
    {
        SqlHelper ObjSqlhelper = new SqlHelper();
        public DataSet ValidUser(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_validateuser", sqlParam);
          
        }
        public DataSet ValidUserByUser(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_validateuser_ByUser", sqlParam);

        }
        
        public int Insert_NewUsers(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteNonQuery(CommandType.StoredProcedure, "Usp_Createnewuser", sqlParam);
        }
        public DataSet Get_AllRegions()
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetRegions");
        }
        public DataSet GetuserforEdit(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_Getuserforedit", sqlParam);
        }

        public DataSet GetROles()
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetRoles");
        }

        public DataSet Get_Searchuser(SqlParameter[] sqlParam)
        { return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetsearchUsers", sqlParam); }


        public int? UpdatePassword(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteNonQuery(CommandType.StoredProcedure, "Usp_UpdateUserPassword", sqlParam);
        }
     

        //public SqlDataReader ValidUser(string Password, long UserId)
        //{
        //    return ObjSqlhelper.ExecuteReader(CommandType.Text, "Select LoginID from Users where LoginID = '" + UserId + "' and DebitPassword = dbo.Encr('" + Password + "') and Active = 1");
        //}


        public DataSet Get_AllRegions_for_RM(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetRegions_For_RM", sqlParam);
        }
        public int UpdateLastLogin(SqlParameter[] paramUpdateLastLogin)
        {
            return (int)ObjSqlhelper.ExecuteNonQuery(CommandType.StoredProcedure, "usp_UpdateULastLogin", paramUpdateLastLogin);
        }

        public DataSet selectUserDetailsByUserName(SqlParameter[] param)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "usp_get_User_details_by_LoginId", param);
        }
    }
}
