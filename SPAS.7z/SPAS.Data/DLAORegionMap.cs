﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace SPAS.Data
{
  public  class DLAORegionMap
    {

        SqlHelper ObjSqlhelper = new SqlHelper();

        public DataSet Get_Channel()
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetChannel");

        }

        public DataSet Get_Region()
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetRegions");

        }
        public DataSet Get_AOmapSearch(SqlParameter[] sqlparam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "USP_Get_AORegionmapping", sqlparam);
        }

        public DataSet Get_AOmap()
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "USP_Get_AORegionmappingNEW");
        }

        public DataSet GetAOusers()
        {

            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetAOusers");

        }
        public DataSet Get_AOmapEDIT(SqlParameter[] sqlparam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "USP_Get_AORegionmappingEDIT", sqlparam);

        }

        public int Insert_AOMapping(SqlParameter[] sqlparam)
        {
            return ObjSqlhelper.ExecuteNonQuery(CommandType.StoredProcedure, "Usp_CreateNewAOmap", sqlparam);

        }

       
    }
}
