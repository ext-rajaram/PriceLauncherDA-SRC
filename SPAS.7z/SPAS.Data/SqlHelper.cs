﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace SPAS.Data
{
    /// <summary>
    /// Author: Dinesh Patel
    /// Created Date: 11-Oct-2011
    /// Last Modified date : 
    /// Description: Main class which contains all the database accessing methods.
    /// </summary>
    public sealed class SqlHelper
    {

        public struct sqlParameteres
        {
            public string xName;
            public object xValue;
            public System.Data.ParameterDirection xDirection;
            public int xSize;
            public System.Data.SqlDbType xDbType;
        }

        private static String ConnectionString
        {
            get { return ConfigurationSettings.AppSettings["ConnectionString"].ToString(); }

        }
        public DataTable ExecuteDataTable(CommandType commandType, string commandText, params SqlParameter[] arrParam)
        {
            DataTable dt = new DataTable();
            SqlConnection cn = new SqlConnection(ConnectionString);

            SqlCommand cmd = new SqlCommand("", cn);
            cmd.CommandType = commandType;
            cmd.CommandText = commandText;


            if (cn.State == ConnectionState.Closed || cn.State == ConnectionState.Broken)
                cn.Open();

            try
            {
                if (arrParam != null)
                {
                    foreach (SqlParameter param in arrParam)
                        cmd.Parameters.Add(param);
                }

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;  //throw new Exception("Error: " + ex.Message);
            }
            finally
            {
                cmd.Parameters.Clear();
                cmd.Dispose();
                cn.Close();
            }
        }

        public DataSet ExecuteDataSet(CommandType commandType, string commandText, params SqlParameter[] arrParam)//static
        {
            DataSet ds = new DataSet();
            SqlConnection cn = new SqlConnection(ConnectionString);

            SqlCommand cmd = new SqlCommand("", cn);
            cmd.CommandType = commandType;
            cmd.CommandText = commandText;


            if (cn.State == ConnectionState.Closed || cn.State == ConnectionState.Broken)
                cn.Open();

            try
            {
                if (arrParam != null)
                {
                    foreach (SqlParameter param in arrParam)

                        cmd.Parameters.Add(param);
                }

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                return ds;
            }
            catch (Exception ex)
            {
                throw ex;  //throw new Exception("Error: " + ex.Message);
            }
            finally
            {
                cmd.Parameters.Clear();
                cmd.Dispose();
                cn.Close();
            }
        }
        public string ExecuteNonQuery(CommandType commandType, string commandText, string strOutParamName, params SqlParameter[] arrParam)
        {
            SqlConnection cn;
            cn = new SqlConnection(ConnectionString);

            SqlCommand cmd = new SqlCommand("", cn);
            cmd.CommandType = commandType;
            cmd.CommandText = commandText;
            cmd.CommandTimeout = 0;
            string strOutParamVal = "";
            int retval = 0;
            if (cn.State == ConnectionState.Closed || cn.State == ConnectionState.Broken)
                cn.Open();

            try
            {
                if (arrParam != null)
                {
                    foreach (SqlParameter param in arrParam)

                        cmd.Parameters.Add(param);
                }


                retval = cmd.ExecuteNonQuery();


                if (strOutParamName != "")
                {
                    strOutParamVal = Convert.ToString(cmd.Parameters[strOutParamName].Value);
                }
                return strOutParamVal;

            }
            catch (Exception ex)
            {
                throw ex;  //new Exception("Error: " + ex.Message);
            }
            finally
            {
                cmd.Parameters.Clear();
                cmd.Dispose();
                cn.Close();
            }
        }

        public int ExecuteNonQuery(CommandType commandType, string commandText, params SqlParameter[] arrParam)
        {
            SqlConnection cn;
            cn = new SqlConnection(ConnectionString);

            SqlCommand cmd = new SqlCommand("", cn);
            cmd.CommandType = commandType;
            cmd.CommandText = commandText;
            cmd.CommandTimeout = 0;
            //string strOutParamVal = "";
            int retval = 0;
            if (cn.State == ConnectionState.Closed || cn.State == ConnectionState.Broken)
                cn.Open();

            try
            {
                bool mustCloseConnection = false;
                PrepareCommand(cmd, cn, (SqlTransaction)null, commandType, commandText, arrParam, out mustCloseConnection);
                retval = cmd.ExecuteNonQuery();


                // Detach the SqlParameters from the command object, so they can be used again
                cmd.Parameters.Clear();
                if (mustCloseConnection)
                    cn.Close();
                return retval;

            }
            catch (Exception ex)
            {
                throw ex;  //new Exception("Error: " + ex.Message);
            }
            finally
            {
                cmd.Parameters.Clear();
                cmd.Dispose();
                cn.Close();
            }


        }

        public int ExecuteNonQuery(CommandType commandType, string commandText, ref SqlConnection cn, ref SqlTransaction sqltrn, params SqlParameter[] arrParam)
        {
            //SqlConnection cn;
           // cn = new SqlConnection(ConnectionString);

            SqlCommand cmd = new SqlCommand("", cn);
            cmd.CommandType = commandType;
            cmd.CommandText = commandText;
            cmd.CommandTimeout = 0;
            //string strOutParamVal = "";
            int retval = 0;
            //if (cn.State == ConnectionState.Closed || cn.State == ConnectionState.Broken)
            //    cn.Open();

            try
            {
                bool mustCloseConnection = false;
                PrepareCommand(cmd, cn, (SqlTransaction)sqltrn, commandType, commandText, arrParam, out mustCloseConnection);
                retval = cmd.ExecuteNonQuery();


                // Detach the SqlParameters from the command object, so they can be used again
                cmd.Parameters.Clear();
                //if (mustCloseConnection)
                //    cn.Close();
                return retval;

            }
            catch (Exception ex)
            {
                throw ex;  //new Exception("Error: " + ex.Message);
            }
            finally
            {
                cmd.Parameters.Clear();
                cmd.Dispose();
                //cn.Close();
            }


        }

        public Object ExecuteScalar(CommandType commandType, string commandText, string DB = "", string strOutParamName = "", params SqlParameter[] arrParam)
        {
            SqlConnection cn;

            cn = new SqlConnection(ConnectionString);

            //            SqlConnection cn = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("", cn);
            cmd.CommandType = commandType;
            cmd.CommandText = commandText;

            Object retval;
            if (cn.State == ConnectionState.Closed || cn.State == ConnectionState.Broken)
                cn.Open();

            try
            {
                if (arrParam != null)
                {
                    foreach (SqlParameter param in arrParam)

                        cmd.Parameters.Add(param);
                }

                retval = cmd.ExecuteScalar();

                return retval;

            }
            catch (Exception ex)
            {
                throw ex;  //throw new Exception("Error: " + ex.Message);
            }
            finally
            {
                cmd.Parameters.Clear();
                cmd.Dispose();
                cn.Close();
            }
        }


        public string ExecuteNonQueryparse(CommandType commandType, string commandText, string strOutParamName, params SqlParameter[] arrParam)
        {
            SqlConnection cn;
            cn = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("", cn);
            cmd.CommandType = commandType;
            cmd.CommandText = commandText;
            cmd.CommandTimeout = 0;
            string strOutParamVal = "";
            int retval = 0;
            if (cn.State == ConnectionState.Closed || cn.State == ConnectionState.Broken)
                cn.Open();

            try
            {
                if (arrParam != null)
                {
                    foreach (SqlParameter param in arrParam)

                        cmd.Parameters.Add(param);
                }


                retval = cmd.ExecuteNonQuery();

                SPAS.Data.GlobalClass.GlobalVar = Convert.ToString(retval);

                if (strOutParamName != "")
                {
                    strOutParamVal = Convert.ToString(cmd.Parameters[strOutParamName].Value);
                }
                return strOutParamVal;

            }
            catch (Exception ex)
            {
                throw ex;  //new Exception("Error: " + ex.Message);
            }
            finally
            {
                cmd.Parameters.Clear();
                cmd.Dispose();
                cn.Close();
            }
        }


        /// <summary>
        /// This enum is used to indicate whether the connection was provided by the caller, or created by SqlHelper, so that
        /// we can set the appropriate CommandBehavior when calling ExecuteReader()
        /// </summary>
        private enum SqlConnectionOwnership
        {
            /// <summary>Connection is owned and managed by SqlHelper</summary>
            Internal,
            /// <summary>Connection is owned and managed by the caller</summary>
            External
        }
        public SqlDataReader ExecuteReader(CommandType commandType, string commandText, params SqlParameter[] commandParameters)
        {
            SqlConnection connection = null;
            try
            {
                connection = new SqlConnection(ConnectionString);
                connection.Open();

                // Call the private overload that takes an internally owned connection in place of the connection string
                return ExecuteReader(connection, null, commandType, commandText, commandParameters, SqlConnectionOwnership.Internal);
            }
            catch
            {
                // If we fail to return the SqlDatReader, we need to close the connection ourselves
                if (connection != null) connection.Close();
                throw;
            }

        }

        /// <summary>
        /// Create and prepare a SqlCommand, and call ExecuteReader with the appropriate CommandBehavior.
        /// </summary>
        /// <remarks>
        /// If we created and opened the connection, we want the connection to be closed when the DataReader is closed.
        /// 
        /// If the caller provided the connection, we want to leave it to them to manage.
        /// </remarks>
        /// <param name="connection">A valid SqlConnection, on which to execute this command</param>
        /// <param name="transaction">A valid SqlTransaction, or 'null'</param>
        /// <param name="commandType">The CommandType (stored procedure, text, etc.)</param>
        /// <param name="commandText">The stored procedure name or T-SQL command</param>
        /// <param name="commandParameters">An array of SqlParameters to be associated with the command or 'null' if no parameters are required</param>
        /// <param name="connectionOwnership">Indicates whether the connection parameter was provided by the caller, or created by SqlHelper</param>
        /// <returns>SqlDataReader containing the results of the command</returns>
        private static SqlDataReader ExecuteReader(SqlConnection connection, SqlTransaction transaction, CommandType commandType, string commandText, SqlParameter[] commandParameters, SqlConnectionOwnership connectionOwnership)
        {
            if (connection == null) throw new ArgumentNullException("connection");

            bool mustCloseConnection = false;
            // Create a command and prepare it for execution
            SqlCommand cmd = new SqlCommand();
            try
            {
                if (commandParameters != null)
                {
                    foreach (SqlParameter param in commandParameters)

                        cmd.Parameters.Add(param);
                }


                // Create a reader
                SqlDataReader dataReader;

                // Call ExecuteReader with the appropriate CommandBehavior
                if (connectionOwnership == SqlConnectionOwnership.External)
                {
                    dataReader = cmd.ExecuteReader();
                }
                else
                {
                    dataReader = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                }

                // Detach the SqlParameters from the command object, so they can be used again.
                // HACK: There is a problem here, the output parameter values are fletched 
                // when the reader is closed, so if the parameters are detached from the command
                // then the SqlReader can´t set its values. 
                // When this happen, the parameters can´t be used again in other command.
                bool canClear = true;
                foreach (SqlParameter commandParameter in cmd.Parameters)
                {
                    if (commandParameter.Direction != ParameterDirection.Input)
                        canClear = false;
                }

                if (canClear)
                {
                    cmd.Parameters.Clear();
                }

                return dataReader;
            }
            catch
            {
                if (mustCloseConnection)
                    connection.Close();
                throw;
            }
        }


        #region private utility methods & constructors
        /// <summary>
        /// This method opens (if necessary) and assigns a connection, transaction, command type and parameters 
        /// to the provided command
        /// </summary>
        /// <param name="command">The SqlCommand to be prepared</param>
        /// <param name="connection">A valid SqlConnection, on which to execute this command</param>
        /// <param name="transaction">A valid SqlTransaction, or 'null'</param>
        /// <param name="commandType">The CommandType (stored procedure, text, etc.)</param>
        /// <param name="commandText">The stored procedure name or T-SQL command</param>
        /// <param name="commandParameters">An array of SqlParameters to be associated with the command or 'null' if no parameters are required</param>
        /// <param name="mustCloseConnection"><c>true</c> if the connection was opened by the method, otherwose is false.</param>
        private static void PrepareCommand(SqlCommand command, SqlConnection connection, SqlTransaction transaction, CommandType commandType, string commandText, SqlParameter[] commandParameters, out bool mustCloseConnection)
        {
            if (command == null) throw new ArgumentNullException("command");
            if (commandText == null || commandText.Length == 0) throw new ArgumentNullException("commandText");

            // If the provided connection is not open, we will open it
            if (connection.State != ConnectionState.Open)
            {
                mustCloseConnection = true;
                connection.Open();
            }
            else
            {
                mustCloseConnection = false;
            }

            // Associate the connection with the command
            command.Connection = connection;

            // Set the command text (stored procedure name or SQL statement)
            command.CommandText = commandText;

            // If we were provided a transaction, assign it
            if (transaction != null)
            {
                if (transaction.Connection == null) throw new ArgumentException("The transaction was rollbacked or commited, please provide an open transaction.", "transaction");
                command.Transaction = transaction;
            }

            // Set the command type
            command.CommandType = commandType;

            // Attach the command parameters if they are provided
            if (commandParameters != null)
            {
                AttachParameters(command, commandParameters);
            }
            return;
        }

        // Since this class provides only static methods, make the default constructor private to prevent 
        // instances from being created with "new SqlHelper()"
        //private SqlHelper() { }

        /// <summary>
        /// This method is used to attach array of SqlParameters to a SqlCommand.
        /// 
        /// This method will assign a value of DbNull to any parameter with a direction of
        /// InputOutput and a value of null.  
        /// 
        /// This behavior will prevent default values from being used, but
        /// this will be the less common case than an intended pure output parameter (derived as InputOutput)
        /// where the user provided no input value.
        /// </summary>
        /// <param name="command">The command to which the parameters will be added</param>
        /// <param name="commandParameters">An array of SqlParameters to be added to command</param>
        private static void AttachParameters(SqlCommand command, SqlParameter[] commandParameters)
        {
            if (command == null) throw new ArgumentNullException("command");
            if (commandParameters != null)
            {
                foreach (SqlParameter p in commandParameters)
                {
                    if (p != null)
                    {
                        // Check for derived output value with no value assigned
                        if ((p.Direction == ParameterDirection.InputOutput ||
                            p.Direction == ParameterDirection.Input) &&
                            (p.Value == null))
                        {
                            p.Value = DBNull.Value;
                        }
                        command.Parameters.Add(p);
                    }
                }
            }
        }
        #endregion private utility methods & constructors

    }
}
