﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;


namespace SPAS.Data
{
   public class SchemeReportDL
   {
       SqlHelper ObjSqlhelper = new SqlHelper();
        public DataSet getReportSchemerequestdetails(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "usp_get_Report_SchemeRequest_details", sqlParam);
        }

        public DataSet getReportSchemeFinance(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "usp_get_Report_Scheme_Finance_Report", sqlParam);
        }

        public DataSet getApprovedListofSchemesReport(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "usp_get_ApprovedListofSchemes_Report", sqlParam);
        }

        public DataSet getApprovedListofSchemeSettlementReport(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "usp_get_ApprovedListofSchemeSettlement_Report", sqlParam);
        }

        public DataSet getApprovedListofSchemeSettlementReportAO(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "usp_get_ApprovedListofSchemeSettlement_Report_AO", sqlParam);
        }
    }
}
