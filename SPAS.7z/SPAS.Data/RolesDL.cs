﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
namespace SPAS.Data
{
    public class RolesDL
    {
        SqlHelper ObjSqlhelper = new SqlHelper();
        public SqlDataReader GetRoleByUserId(long UserId)
        {

            return ObjSqlhelper.ExecuteReader(CommandType.Text, "Select Top 1 R.RoleId, R.RoleShort As RoleName, RoleName as RolesDescription from tblUserInRole U with(nolock) Inner Join tblRoles R with(nolock) on U.RoleId = R.RoleId where U.UserId = " + UserId, null);
        }

        public DataSet SelectAllRolesbyUserId(long UserId)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.Text, "Select Top 1 R.RoleId, R.RoleShort as RoleName,R.RoleName as RolesDescription  from tblUserInRole U with(nolock) Inner Join tblRoles R with(nolock) on U.RoleId = R.RoleId where U.UserId= " + UserId, null);
        }

        public DataTable SelectAllRoles()
        {
            return ObjSqlhelper.ExecuteDataTable(CommandType.Text, "Select R.RoleId, R.RoleShort as RoleName,R.RoleName as RolesDescription  from tblRoles R with(nolock)", null);
        }

    }
}
