﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;


namespace SPAS.Data
{
    public class RequestApprovalDL
    {
        SqlHelper ObjSqlhelper = new SqlHelper();
        public DataSet getrequestCompletedetailsforApproval(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "usp_get_request_Complete_details_for_Approval", sqlParam);
        }

        public DataSet getApprovedRequestByRequestId(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "usp_get_ApprovedRequest_ByRequestId", sqlParam);
        }

        public int Save_RequestApprovalDetails(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteNonQuery(CommandType.StoredProcedure, "usp_save_ApprovalRequest", sqlParam);
        }

        public int Save_RequestApprovalByPH_PC(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteNonQuery(CommandType.StoredProcedure, "usp_save_ApprovalByPH_PC", sqlParam);
        }

        public DataTable getPriceDownload(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataTable(CommandType.StoredProcedure, "usp_get_Price_Download", sqlParam);
        }

        public DataSet getApprovedRequestHeader_for_Approver(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "usp_get_request_header_ApprovedByUserId", sqlParam);
        }

    }
}
