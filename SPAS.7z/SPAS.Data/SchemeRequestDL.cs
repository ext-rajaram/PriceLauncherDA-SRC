﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace SPAS.Data
{
    public class SchemeRequestDL
    {
        SqlHelper ObjSqlhelper = new SqlHelper();
        public DataSet getAllGroup2()
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetAll_Group2", null);
        }

        public DataSet getAllChannels()
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetAll_Channel", null);
        }

        public DataSet getBranchOnRegion(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_Get_BranchOnRegion", sqlParam);
        }

        public DataSet getCustomerOnRegion(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_Get_CustomerOnRegion", sqlParam);
        }

        public DataSet getAllBG()
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetAll_BG", null);
        }

        public DataSet getBUOnBG(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_Get_BUOnBG", sqlParam);
        }

        public DataSet getSAGOnBU(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_Get_SAGOnBU", sqlParam);
        }
        
        public DataSet getProductOnSAG(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_Get_ProductsOnSAG", sqlParam);
        }

        public DataSet getApprovedRequests()
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_Get_SchemeAllApprovedRequests", null);
        }

        public DataSet getSchemeCustomersOnRequest(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_Get_SchemeCustomers_OnRequest", sqlParam);
        }

        public DataSet getSchemeBGOnRequest(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_Get_SchemeBGs_OnRequest", sqlParam);
        }

        public int Save_SchemeRequestDetails(SqlParameter[] sqlParam, ref System.Data.SqlClient.SqlConnection cn, ref System.Data.SqlClient.SqlTransaction sqltrn)
        {
            return ObjSqlhelper.ExecuteNonQuery(CommandType.StoredProcedure, "usp_save_SchemeRequest",ref cn,ref sqltrn, sqlParam);
        }

        public int Save_SchemeAttachement(SqlParameter[] sqlParam, ref System.Data.SqlClient.SqlConnection cn, ref System.Data.SqlClient.SqlTransaction sqltrn)
        {
            return ObjSqlhelper.ExecuteNonQuery(CommandType.StoredProcedure, "usp_save_SchemeAttachment", ref cn, ref sqltrn, sqlParam);
        }

       
        public int Save_SchemeRollOut(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteNonQuery(CommandType.StoredProcedure, "usp_save_SchemeRollOut", sqlParam);
        }

        public DataSet getSchemerequestdetails(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "usp_get_SchemeRequest_details", sqlParam);
        }

        public DataSet getSchemerequestdetailsforApprover(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "usp_get_SchemeRequest_details_for_Approver", sqlParam);
        }

       

        public int IsReqPendingwithsameCMM(Int64 RequestId, int CMMId)
        {
            return (int)ObjSqlhelper.ExecuteScalar(CommandType.Text, "select count(Id) from tblSchemeCMMAprover with(nolock) where StatusId=1 and SchemeRequestId=" + RequestId + " and CMMId=" + CMMId + "");
        }

        public DataSet getRegionOnUser(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetRegionsOnUser", sqlParam);
        }

        public DataSet getAttachmentOnId(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_Get_SchemeAttachmentOnId", sqlParam);
        }

        public int CloseScheme(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteNonQuery(CommandType.StoredProcedure, "usp_Close_Scheme", sqlParam);
        }


        public int ReopenScheme(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteNonQuery(CommandType.StoredProcedure, "usp_Reopen_Scheme", sqlParam);
        }

        public DataSet getAllChannelsForRM(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetAll_Channel_SchemeRM", sqlParam);
        }

        public int Save_SchemeRollOutNew(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteNonQuery(CommandType.StoredProcedure, "usp_save_SchemeRollOut_New", sqlParam);
        }
    }
}
