﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;


namespace SPAS.Data
{
  public  class DLRCM
    {

        SqlHelper ObjSqlhelper = new SqlHelper();

        public DataSet Get_Channel()
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetChannel");

        }

        public DataSet Get_Region()
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetRegions");

        }
        public DataSet Get_RCMmapSearch(SqlParameter[] sqlparam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "USP_Get_RCMRegionmapping", sqlparam);
        }

        public DataSet Get_RCMmap()
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "USP_Get_RCMRegionmapping");
        }

        public DataSet GetRCMusers()
        {

            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetRCMusers");

        }
        public DataSet Get_RCMmapEDIT(SqlParameter[] sqlparam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "USP_Get_RCMRegionmappingEDIT", sqlparam);

        }

        public int Insert_RCMMapping(SqlParameter[] sqlparam)
        {
            return ObjSqlhelper.ExecuteNonQuery(CommandType.StoredProcedure, "Usp_CreateNewRCMmap", sqlparam);

        }
    }
}
