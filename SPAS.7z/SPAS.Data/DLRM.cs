﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;


namespace SPAS.Data
{
   public class DLRM
    {
       SqlHelper ObjSqlhelper = new SqlHelper();


       public DataSet Get_Channel()
       {
           return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetChannel");   

       }

          public DataSet Get_Region()
       {
           return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetRegions");    

       }

          public DataSet Get_RMmapSearch(SqlParameter[] sqlparam)
          {
              return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "USP_Get_RMRegionmapping", sqlparam);
          }

          public DataSet Get_RMmap()
          {
              return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "USP_Get_RMRegionmapping");
          }

          public DataSet Getusers()
          {
              
                  return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_Getusers");
              
          }
       

          public DataSet Get_RMmapEDIT(SqlParameter[] sqlparam)
          {
              return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "USP_Get_RMRegionmappingEDIT", sqlparam);
 
          }

          public int Insert_RMMapping(SqlParameter[] sqlparam)
          
          {
              return ObjSqlhelper.ExecuteNonQuery(CommandType.StoredProcedure, "Usp_CreateNewRMmap", sqlparam);
          
          }

        
    }
}
