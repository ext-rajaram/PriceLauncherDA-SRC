﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace SPAS.Data
{
    public  class SchemeSettlementApprovalDL
    {
        SqlHelper ObjSqlhelper = new SqlHelper();

        public DataSet getSchemeSettlementdetailsforApprover(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "usp_get_Scheme_Settlement_details_for_Approver", sqlParam);
        }


        public int Approve_Scheme_Settlement_Request(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteNonQuery(CommandType.StoredProcedure, "usp_approve_Scheme_Settlement_request", sqlParam);
        }

        public DataSet getSchemeSettlementCustomer(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "usp_get_Scheme_Settlement_customer_details", sqlParam);
        }
    }
}
