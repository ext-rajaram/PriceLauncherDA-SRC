﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace SPAS.Data
{
    public class SchemeSettlementRequestDL
    {
        SqlHelper ObjSqlhelper = new SqlHelper();

        public DataSet getSchemeSettlementDetails(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "usp_Get_Scheme_Settlementdetails", sqlParam);
        }

        public DataSet getSchemeSettlementOnRequest(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "usp_Get_Scheme_SettlemenOnRequest", sqlParam);
        }

        public DataSet getSchemeCustomersSettledAmt(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_Get_SchemeCustomersSettledAmt", sqlParam);
        }

        public DataSet getSchemeSettledDetails(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "usp_get_Scheme_Settled_Request_Details", sqlParam);
        }

        public int Submit_SchemeSettlementRequest(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteNonQuery(CommandType.StoredProcedure, "usp_submit_Settlements", sqlParam);
        }

        public int Save_SchemeSettlementDetails(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteNonQuery(CommandType.StoredProcedure, "usp_save_SchemeSettlement", sqlParam);
        }

        public int DeleteSettlement(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteNonQuery(CommandType.StoredProcedure, "usp_Delete_Settlement", sqlParam);
        }

        public DataSet getSchemeSettledCNDetails(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "usp_get_SchemeSettledCNDetails", sqlParam);
        }

        public int save_Scheme_Settled_CN_deatils(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteNonQuery(CommandType.StoredProcedure, "usp_save_Scheme_Settled_CN_deatils", sqlParam);
        }

        public DataSet getClosedSchemeSettlementDetails(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "usp_Get_Closed_Scheme_Settlementdetails", sqlParam);
        }
    }
}
