﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
namespace SPAS.Data
{
  public  class ReportDL
    {

        SqlHelper ObjSqlhelper = new SqlHelper();
        public DataSet getBGDetail()
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.Text, "select BGId,BGCode from tblBG with(nolock) order by BGCode", null);

        }

        public DataSet getReportDetail(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "usp_rpt_get_RequestDetails", sqlParam);

        }
    }
}
