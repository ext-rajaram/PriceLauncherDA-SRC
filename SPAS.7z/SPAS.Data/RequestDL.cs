﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace SPAS.Data
{
    public class RequestDL
    {
        SqlHelper ObjSqlhelper = new SqlHelper();
        public DataSet getsoldtocustomer(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "usp_get_sold_to_customer", sqlParam);
        }

       
      
        public DataSet getshiptocustomer(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "usp_get_ship_to_customer", sqlParam);
        }

        public DataSet getBranchPlant()
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "usp_get_BranchPlant", null);
        }

        public DataSet getApprovedItem(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "usp_get_Approved_Material", sqlParam);
        }

             
        public DataSet getSoldToPartyRegion(Int64 SoldToID)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.Text, "Select r.RegionID from tblCustomer c with(nolock) inner join tblRegion r with(nolock)on r.RegionCode=c.RegionCode where c.CustomerCode='" + SoldToID + "' ", null);
        }

        public DataSet getChannelDetails(Int64 ShiptoCustomerCode)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.Text, "Select Channel,Isnull(Group2,'') as Group2,RegionCode from tblCustomer with(nolock) where CustomerCode='" + ShiptoCustomerCode + "' ", null);
        }

        public DataSet getMaterialSearchdata(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "usp_get_Plant_Channel_wise_material_details", sqlParam);
        }


        public int Save_RequestDetails(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteNonQuery(CommandType.StoredProcedure, "usp_save_request", sqlParam);
        }

        public DataSet getrequestdetails(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "usp_get_request_details", sqlParam);
        }


        public DataSet getrequestCompletedetailsforView(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "usp_get_request_Complete_details_for_View", sqlParam);
        }

        public DataSet getOrderConfirmationData(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "usp_get_OrderConfirmationItems", sqlParam);
        }

        public DataSet getpendingforapprovalrequestHeader_for_Approver(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "usp_get_pending_for_approval_request_header_for_Approver", sqlParam);
        }

      
        public int Save_Request_Order_Confirmation(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteNonQuery(CommandType.StoredProcedure, "usp_Save_Request_OrderDesk_Confirmation", sqlParam);
        }

        public DataTable getOrderDownload(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataTable(CommandType.StoredProcedure, "usp_get_Order_Download", sqlParam);
        }

        public int DeleteOrderConfirmation(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteNonQuery(CommandType.StoredProcedure, "usp_Delete_OrderConfirmation", sqlParam);
        }

        public int Save_OrderConfirmationRequest(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteNonQuery(CommandType.StoredProcedure, "usp_save_OrderConfirmation", sqlParam);
        }

        public int SubmitOrderConfirmation(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteNonQuery(CommandType.StoredProcedure, "usp_Submit_OrderConfirmation", sqlParam);
        }

        public int AssignSoldToForNewCustomer(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteNonQuery(CommandType.StoredProcedure, "usp_AssignSoldTo_ForNewCustomer", sqlParam);
        }

        public DataSet get_OrderDesk_Details_OrderConfirmation(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "usp_get_OrderDesk_Details_OrderConfirmation", sqlParam);
        }

        public int save_RebateCommissionRequestPODetails(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteNonQuery(CommandType.StoredProcedure, "usp_save_RebateCommissionRequestPODetails", sqlParam);
        }
        

    }
}
