﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SPAS.Data
{
    public static class GlobalClass
    {
        private static string m_globalVar_Affectedrowscount = "";
        public static string GlobalVar
        {
            get { return m_globalVar_Affectedrowscount; }
            set { m_globalVar_Affectedrowscount = value; }
        }
    }
}
