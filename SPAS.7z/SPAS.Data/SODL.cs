﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace SPAS.Data
{
   public class SODL
    {
        SqlHelper ObjSqlhelper = new SqlHelper();
        public DataSet get_Order_Confirmation_Details(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "usp_get_Order_Confirmation_Details", sqlParam);
        }

        public DataSet get_Order_Confirmation_Details_for_SO(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "usp_get_Order_Confirmation_Details_For_SO", sqlParam);
        }

        public DataSet get_SO_Details_For_Order_Desk(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "usp_get_SO_Details_For_Order_Desk", sqlParam);
        }

        public int Save_RequestSOGenerationlDetails(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteNonQuery(CommandType.StoredProcedure, "usp_save_RequestSOGenerationlDetails", sqlParam);
        }

        public DataSet get_SO_Header_View(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "usp_get_SO_Header_View", sqlParam);
        }

        public DataSet get_SO_Details_View(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "usp_get_SO_Details_View", sqlParam);
        }

        public DataSet get_SO_UploadedFiles(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "USP_get_SO_UploadedFile", sqlParam);
        }

    }
}
