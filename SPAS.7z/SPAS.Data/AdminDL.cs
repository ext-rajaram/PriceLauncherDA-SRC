﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace SPAS.Data
{
    public class AdminDL
    {
        SqlHelper ObjSqlhelper = new SqlHelper();
        public DataSet Get_AllUsersOnRole(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_Get_AllUsersOnRole", sqlParam);
        }

        public DataSet Get_AllSAG()
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetALL_SAG");
        }

        public DataSet Get_AllBU()
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetALL_BU");
        }

        public DataSet Get_AllPrdMgrSAGMapping()
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_Get_AllPrdMgrSAGMapping");
        }

        public DataSet Get_AllCatgContrrBUMapping()
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_Get_AllCategoryControllerBUMapping");
        }

        public DataSet Getallusers()
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_Get_AllUsers");
        }
        
        public DataSet Get_AllMktManagerMapping()
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_Get_AllMarketingManagerBUMapping");
        }

        public int Insert_PrdMgrSAGMapping(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteNonQuery(CommandType.StoredProcedure, "Usp_Insert_PrdMgrSAGMapping", sqlParam);
        }

        public int Insert_CatgContrBUMapping(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteNonQuery(CommandType.StoredProcedure, "[Usp_Insert_CatgControllerMapping]", sqlParam);
        }

        public int Insert_MktManagerBUMapping(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteNonQuery(CommandType.StoredProcedure, "Usp_Insert_MarketingManagerMapping", sqlParam);
        }

        public DataSet GetplantstateMap()
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetpalntStatemapping");
        }

        public DataSet Getplantsearch(SqlParameter[] sqlParam)

        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetSearchpalntStatemapping", sqlParam);
 
        }
        public DataSet GetStates()
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetStates");
        }

        public int InsertPlantstatemap(SqlParameter[] sqlparam)
        {
            return ObjSqlhelper.ExecuteNonQuery(CommandType.StoredProcedure, "Usp_AddplantstateMapping", sqlparam);
        }
        public DataSet Getplantstate(SqlParameter[] sqlparam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetplantEdit", sqlparam);

 
        }
        public DataSet Getmaterialcode(SqlParameter[] sqlparam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_Getmaterialcode", sqlparam);
 
        }

       

        public DataSet Get_Bg()
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetBG"); 
 
        }
        public DataSet Get_BgSearch(SqlParameter[] sqlparam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_SearchBindBG", sqlparam);   
        }
        public DataSet Get_BgEdit(SqlParameter[] sqlparam)
        { return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetEditBG", sqlparam); }   

        public int Insert_BG(SqlParameter[] sqlparam)
        {
            return ObjSqlhelper.ExecuteNonQuery(CommandType.StoredProcedure, "Usp_AddBG", sqlparam);
        }
         public DataSet Get_Bu()
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetBU");
 
        }

         public DataSet Get_BuSearch(SqlParameter[] sqlparam)
         {
             return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_SearchBindBU", sqlparam);
         }

        public DataSet Get_BuEdit(SqlParameter[] sqlparam)
        { return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetEditBU", sqlparam);  
        }

        public int Insert_BU(SqlParameter[] sqlparam)
        {
            return ObjSqlhelper.ExecuteNonQuery(CommandType.StoredProcedure, "Usp_AddBU", sqlparam);
        }


         public DataSet Get_mag()
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetMAG");
 
        }

         public DataSet Get_MagSearch(SqlParameter[] sqlparam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_SearchBindMAG", sqlparam);   
        }


        public DataSet Get_MagEdit(SqlParameter[] sqlparam)
         {
             return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetEditMAG", sqlparam);  
        }
        public int Insert_MAG(SqlParameter[] sqlparam)
        {
            return ObjSqlhelper.ExecuteNonQuery(CommandType.StoredProcedure, "Usp_AddMAG", sqlparam);
        }

        public DataSet Get_Min3npSearch(SqlParameter[] sqlparam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetMaterialcoderate", sqlparam);
        }
        public DataSet ValidateProcessmin3npUploadedData()
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_ValidateAndProcessmin3npUploadedData");
        }


          public DataSet ValidateAndProcessmaterialstatetax()


        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_ValidateAndProcessmaterialstatetax");
        }

      

        public DataSet Get_searchMatrerilstatetax(SqlParameter[] sqlparam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetsEARCHMatrerilstatetax", sqlparam);
        }

        public DataSet Get_SearchTaxBu(SqlParameter[] sqlparam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetSearchTaxBu", sqlparam);
 
        }

        public DataSet ValidateAndProcessBUstateregiontax()
        {
            try
            {
                return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_ValidateAndProcessBUstateregiontax");
            }
            catch (Exception e)
            {
                throw e;
            }
            
        }

        public DataSet Get_sag()
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetSAG");

        }

        public DataSet GetSagSearch(SqlParameter[] sqlparam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetSearchSAG", sqlparam); 
        }

        public int Insert_SAG(SqlParameter[] sqlparam)
        {
            return ObjSqlhelper.ExecuteNonQuery(CommandType.StoredProcedure, "Usp_AddSAG", sqlparam);
        }


        public DataSet Get_SagEdit(SqlParameter[] sqlparam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetEditSAG", sqlparam);
        }

        public DataSet Get_Group2cod()
        { 
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetGroup2COD"); 
        }

        public int Insert_Group2(SqlParameter[] sqlparam)
        {
            return ObjSqlhelper.ExecuteNonQuery(CommandType.StoredProcedure, "Usp_AddGroup2COD", sqlparam);
        }

        public DataSet Delete_Group2cod(SqlParameter[] sqlparam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_DeleteGroup2COD", sqlparam);
        }


        public DataSet Get_ExchangeRates()
        { return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetExchangerates");
        }
        public int Insert_Exchangerate(SqlParameter[] sqlparam)
        { 
            return ObjSqlhelper.ExecuteNonQuery(CommandType.StoredProcedure, "Usp_AddExchangerate", sqlparam);
        }

        public DataSet Get_exchangerateEdit(SqlParameter[] sqlparam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetEditexchangerate", sqlparam);
        }

        public DataSet Get_CppMaster(SqlParameter[] sqlparam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetCppmasters", sqlparam);  
        }

        public DataSet ValidateProcessCPPData()
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_ValidateAndProcessCPPData");
        }

        public DataSet Get_Min3npdata()

        { return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_Getmin3npdata"); 
        }

        public DataSet Get_duplicateusers()
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_Getduplicaterole"); 
        }

        public DataSet Get_TaxBUdata()
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetBUtaxData"); 
        }

        public DataSet Get_MaterialTaxData()
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetMaterialtaxData"); 
        }


        public DataSet Get_Regions()
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetStates"); 
 
        }

        public DataSet Get_uers()
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "usp_Getregionordermappinguser"); 
        }

        public DataSet Get_stateorderuser(SqlParameter[] sqlparam)
        { 
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_Getorderdeskmap", sqlparam); 
        }
        public int Insert_NewRegionorderdesk(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteNonQuery(CommandType.StoredProcedure, "Usp_Isertregionaluser", sqlParam);
        }

        public DataSet Get_regionorderforEdit(SqlParameter[] sqlparam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetorderdeskmapforEDIT", sqlparam); 
 
        }

        public DataSet Delete_orderdetails(SqlParameter[] sqlparam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_Deleteorderdeskmap", sqlparam);
        }

        public DataSet Get_BGCodeDesc()
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "USP_Get_BGcode");

        }


        public DataSet Get_BUCodeDesc()
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "USP_Get_BUcode");

        }

        public DataSet Get_ChannelSearch()
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_SearchBindChannel");
        }

        public DataSet Get_ChannelEdit(SqlParameter[] sqlparam)
        { return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetEditChannel", sqlparam); 
        }

        public int Insert_Channel(SqlParameter[] sqlparam)
        {
            return ObjSqlhelper.ExecuteNonQuery(CommandType.StoredProcedure, "Usp_AddChannel", sqlparam);
        }

        public DataSet Get_Channel()
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetChannel");

        }

        public DataSet Get_groupSearch(SqlParameter[] sqlparam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_Getgroup2channelMap", sqlparam);
        }

        public DataSet Get_GroupChannelEdit(SqlParameter[] sqlparam)
        { return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_Getgroup2channelMap", sqlparam); 
        }

        public int Insert_Group(SqlParameter[] sqlparam)
        {
            return ObjSqlhelper.ExecuteNonQuery(CommandType.StoredProcedure, "Usp_AddGroup2", sqlparam);
        }

        public DataSet Get_HNSMaster()
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_Get_HNSMaster");
        }

        public DataSet GetEditHNSMaster(SqlParameter[] sqlparam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetEditHNSMaster", sqlparam);
        }

        public int Insert_HSNMaster(SqlParameter[] sqlparam)
        {
            return ObjSqlhelper.ExecuteNonQuery(CommandType.StoredProcedure, "Usp_AddEditHSNMastre", sqlparam);
        }

    }

}
