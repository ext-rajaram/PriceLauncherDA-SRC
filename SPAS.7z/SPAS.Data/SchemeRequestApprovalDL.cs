﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
namespace SPAS.Data
{
  public class SchemeRequestApprovalDL
    {
      SqlHelper ObjSqlhelper = new SqlHelper();

      public DataSet getSchemeRequest_details_for_View(SqlParameter[] sqlParam)
      {
          return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "usp_get_SchemeRequest_details_for_View", sqlParam);
      }

      public int Approve_Scheme_Request(SqlParameter[] sqlParam)
      {
          return ObjSqlhelper.ExecuteNonQuery(CommandType.StoredProcedure, "usp_approve_Scheme_request", sqlParam);
      }
    }
}
