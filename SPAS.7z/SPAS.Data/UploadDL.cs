﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace SPAS.Data
{
    public class UploadDL
    {
        SqlHelper ObjSqlhelper = new SqlHelper();
        public DataSet ValidateProcessProdHirUploadedData()
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_ValidateAndProcessProdHirUploadedData");
        }
        public DataSet ValidateProcessAGUploadData(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_ValidateAndProcessAGUploadedData", sqlParam);
        }

        public DataSet ValidateProcessMaterialDtlsUploadedData()
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_ValidateAndProcessMaterialDtlsUploadedData");
        }

        public void cleartblMaterialDetailsTemptable()
        {
            ObjSqlhelper.ExecuteNonQuery(CommandType.Text, "truncate table tblMaterialDetailsTemp");
        }

        public DataSet ValidateProcessCustomerUploadedData()
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_ValidateAndProcessCustomerUploadedData");
        }

        public DataSet ValidateProcessShipToSoldToUploadedData()
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_ValidateAndProcessShipToSoldToUploadedData");

        }

        public DataSet Get_CustomerDetail(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "usp_Get_CustomerDetails", sqlParam);
        }

        public DataSet Get_MaterialDetail(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "usp_Get_MaterialDetails", sqlParam);
        }

        public DataSet Get_ProductHiearchyDetail(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "usp_Get_ProductHiearchy", sqlParam);
        }

        public DataSet GetsearchAG(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_SearchBindAG", sqlParam);
        }
        
        public DataSet Get_ShipToSoldToDetail(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "usp_Get_ShipToSoldToCode", sqlParam);
        }
        public DataSet Get_Ag()
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetAG");
        }
        public int Insert_AG(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteNonQuery(CommandType.StoredProcedure, "Usp_AddAG", sqlParam);
        }
        public DataSet GetAGforEdit(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetEditAG", sqlParam);
        }

        public DataSet Get_ProductHierarchydata()
        { return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "usp_get_ProductHierarchydata");
        }

        public DataSet Get_CustomeSoldToShipToData()
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetCustomeSoldToShipToData");
        }

        public DataSet Get_GetCustomerData()
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetCustomerData");
        }

        public DataSet Get_productpriceDta()
        {
            return ObjSqlhelper.ExecuteDataSet(CommandType.StoredProcedure, "Usp_GetProductpriceData");
        }

        public int update_Material_HSN(SqlParameter[] sqlParam)
        {
            return ObjSqlhelper.ExecuteNonQuery(CommandType.StoredProcedure, "Usp_update_Material_HSN", sqlParam);
        }

    }
}
